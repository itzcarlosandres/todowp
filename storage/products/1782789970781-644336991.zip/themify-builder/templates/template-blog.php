<?php
/**
 * Template Post
 * This template can be overridden by copying it to your child_theme_folder/themify-builder/template-blog.php.
 * Access original fields: $args['mod_settings']
 * @author Themify
 */

defined('ABSPATH') || exit;

$mod_name = $args['mod_name'];
$builder_id = $args['builder_id'];
$element_id = $args['module_ID'];
$fields_args=$args['mod_settings']+array(
    'mod_title_' . $mod_name => '',
    'layout_' . $mod_name => 'grid4',
    'post_type_' . $mod_name => $mod_name,
    'term_type' => 'category', // Query By option
    'type_query_' . $mod_name => 'category',
    'category_' . $mod_name => '',
    'query_slug_' . $mod_name => '',
    'sticky_' . $mod_name => 'no',
    'post_per_page_' . $mod_name => '',
    'offset_' . $mod_name => '',
    'order_' . $mod_name => 'desc',
    'orderby_' . $mod_name => 'date',
    'meta_key_' . $mod_name => '',
    'display_' . $mod_name => 'content',
    'excerpt_length_' . $mod_name => '',
    'hide_feat_img_' . $mod_name => 'no',
    'image_size_' . $mod_name => 'large',
    'img_width_' . $mod_name => '',
    'img_height_' . $mod_name => '',
    'unlink_feat_img_' . $mod_name => 'no',
    'hide_post_title_' . $mod_name => 'no',
    'title_tag_' . $mod_name => 'h2',
    'unlink_post_title_' . $mod_name => 'no',
    'hide_post_date_' . $mod_name => 'no',
    'hide_post_meta_' . $mod_name => 'no',
    'hide_author_' . $mod_name => '',
    'hide_category_' . $mod_name => '',
    'hide_comment_' . $mod_name => '',
    'hide_page_nav_' . $mod_name => 'yes',
    'nav_type' => 'standard',
    'animation_effect' => '',
    'hide_empty' => 'no',
    'css_' . $mod_name => '',
    'auto_fullwidth_' . $mod_name => false
);

$post_filter_enabled = isset($fields_args[$mod_name . '_filter']) ? $fields_args[$mod_name . '_filter'] : (isset($fields_args['post_filter']) ? $fields_args['post_filter'] : false);
$post_filter_enabled = !empty($post_filter_enabled) && $post_filter_enabled !== 'no';
$ajax_filter_enabled = false;
if (true === $post_filter_enabled && $fields_args['layout_' . $mod_name] !== 'auto_tiles') {
    $ajax_filter_enabled = isset($fields_args['ajax_filter']) && $fields_args['ajax_filter'] === 'yes';
}
if ( $fields_args['nav_type'] === 'ajax' && $post_filter_enabled ) {
    $ajax_filter_enabled = true;
}
$is_ajax_filter = isset( $_POST['action'] ) && $_POST['action'] === 'themify_ajax_load_more';
$ajax_filter_within = $ajax_filter_enabled
    && isset( $fields_args['ajax_filter_within_results'] )
    && $fields_args['ajax_filter_within_results'] === 'yes';
$ajax_filter_taxonomy = '';
$ajax_filter_term = 0;
if ( true === $is_ajax_filter ) {
    $ajax_filter_taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
    $ajax_filter_term = isset( $_POST['tax'] ) ? absint( wp_unslash( $_POST['tax'] ) ) : 0;
}
if ( isset( $fields_args['category_' . $mod_name] ) ) {
    $fields_args['category_' . $mod_name] = self::get_param_value( $fields_args['category_' . $mod_name] );
}
if ($fields_args['layout_' . $mod_name] === '') {
    $fields_args['layout_' . $mod_name] = 'grid4';
}
$container_class = apply_filters('themify_builder_module_classes', array(
    'module',
    'module-' . $mod_name,
    $element_id,
    $fields_args['css_' . $mod_name]
    ), $mod_name, $element_id, $fields_args);

if (!empty($fields_args['global_styles']) && Themify_Builder::$frontedit_active === false) {
    $container_class[] = $fields_args['global_styles'];
}
if (!empty($fields_args['auto_fullwidth_' . $mod_name]) && $fields_args['auto_fullwidth_' . $mod_name]) {
    $container_class[] = 'tb_fullwidth_image';
}

$container_props = apply_filters('themify_builder_module_container_props', self::parse_animation_effect($fields_args, array(
        'class' => implode(' ', $container_class),
    )), $fields_args, $mod_name, $element_id);

if ( true === $is_ajax_filter && isset( $_POST['page'] ) ) {
    $p = absint( wp_unslash( $_POST['page'] ) );
} else {
    $p = self::get_paged_query();
}

$order = true === $is_ajax_filter && isset( $_POST['order'] ) ? sanitize_text_field( wp_unslash( $_POST['order'] ) ) : $fields_args['order_' . $mod_name];
$orderby = true === $is_ajax_filter && isset( $_POST['orderby'] ) ? sanitize_text_field( wp_unslash( $_POST['orderby'] ) ) : $fields_args['orderby_' . $mod_name];
$meta_key = $fields_args['meta_key_' . $mod_name];
$limit = $fields_args['post_per_page_' . $mod_name];
if (empty($limit)) {
    $limit = get_option('posts_per_page');
}
$mod_name_query = isset( $fields_args['term_type'] ) && $fields_args['term_type'] === 'post_slug' ? $fields_args['term_type'] : $fields_args['type_query_' . $mod_name];
$base_query_taxonomy = $mod_name !== 'post' ? $mod_name . '-category' : $mod_name_query;
$filter_taxonomy = ! empty( $fields_args['post_filter_tax'] ) ? sanitize_key( $fields_args['post_filter_tax'] ) : $base_query_taxonomy;
if ( $ajax_filter_taxonomy === '' || ( $filter_taxonomy !== '' && $ajax_filter_taxonomy !== $filter_taxonomy ) ) {
    $ajax_filter_taxonomy = $filter_taxonomy;
}
$query_taxonomy = $base_query_taxonomy;
$offset = $fields_args['offset_' . $mod_name];
$args = array(
    'post_status' => 'publish',
    'posts_per_page' => $limit,
    'ptb_disable' => true,
    'order' => $order,
    'orderby' => $orderby,
    'paged' => $p,
    'post_type' => $is_ajax_filter && isset( $_POST['post_type'] ) ? sanitize_text_field( wp_unslash( $_POST['post_type'] ) ) : $fields_args['post_type_' . $mod_name],
    'ignore_sticky_posts' => true
);

if ( 'all' === $fields_args['term_type'] ) {
    if ( $fields_args["sticky_{$mod_name}"] === 'yes' ) {
        $args['ignore_sticky_posts'] = false;
    }
}
elseif ( 'post_slug' !== $fields_args['term_type'] ) {
    $terms = $mod_name === 'post' && isset( $fields_args["{$mod_name_query}_post"] ) ? $fields_args["{$mod_name_query}_post"] : $fields_args['category_' . $mod_name];

    if ( ! ( $is_ajax_filter && $ajax_filter_term > 0 && ! $ajax_filter_within ) ) {
        Themify_Builder_Model::parseTermsQuery( $args, $terms, $base_query_taxonomy );
    }
}
elseif ( ! empty( $fields_args['query_slug_' . $mod_name] ) ) {
    $args['post__in'] = Themify_Builder_Model::parse_slug_to_ids( $fields_args['query_slug_' . $mod_name], $args['post_type'] );
}

if ( $is_ajax_filter && $ajax_filter_term > 0 && $ajax_filter_taxonomy !== '' ) {
    Themify_Builder_Model::merge_tax_query_with_ajax_filter( $args, $ajax_filter_taxonomy, $ajax_filter_term );
    $query_taxonomy = $ajax_filter_taxonomy;
}


/* backward compatibility, since Sep 2022 */
if ($orderby === 'meta_value_num') {
    $orderby = 'meta_value';
    $fields_args['meta_key_type'] = 'NUMERIC';
}
/* end backward compatibility */

if (!empty($meta_key) && $orderby === 'meta_value') {
    $args['meta_key'] = $meta_key;
    if (!empty($fields_args['meta_key_type'])) {
        $args['meta_type'] = $fields_args['meta_key_type'];
    }
}

// add offset posts
if ($offset !== '') {
    $args['offset'] = (($p - 1) * $limit) + $offset;
}
// Exclude the current post
if ($mod_name === 'post' && !isset($args['post__in']) && false !== ($id = get_the_ID()) && (Themify_Builder::$is_loop===true || is_singular($id))) {
    $args['post__not_in'] = array($id);
}

Themify_Builder_Model::parse_query_filter($fields_args, $args);
if ( $ajax_filter_enabled ) {
    if ( $is_ajax_filter && $ajax_filter_term > 0 && ! $ajax_filter_within ) {
        unset( $args['post__in'] );
    }
    set_query_var( 'tf_ajax_filter', true );
}
$args = apply_filters("themify_builder_module_{$mod_name}_query_args", $args, $fields_args);
$tf_masonry_terms_taxonomy = true === $post_filter_enabled && $filter_taxonomy !== '' ? $filter_taxonomy : $query_taxonomy;
set_query_var( 'tf_query_tax', $tf_masonry_terms_taxonomy );
$the_query = self::query($args);
$posts = $the_query->posts;

if (empty($posts) && $fields_args['hide_empty'] === 'yes' && Themify_Builder::$frontedit_active === false) {
    return;
}


Themify_Builder_Model::hook_content_start($fields_args);
self::sticky_element_props($container_props,$fields_args);
?>
<!-- module post -->
<div <?php echo themify_get_element_attributes($container_props); ?>>
<?php
$container_props = $container_props = null;
echo Themify_Builder_Component_Module::get_module_title($fields_args, 'mod_title_' . $mod_name);

// The Query
do_action('themify_builder_before_template_content_render');

$class = array('builder-posts-wrap', 'loops-wrapper');
if (!empty($fields_args['post_type_' . $mod_name]) && $fields_args['post_type_' . $mod_name] !== 'post') {
    $class[] = $fields_args['post_type_' . $mod_name];
}
if (($fields_args['layout_' . $mod_name] === 'auto_tiles' || in_array('auto_tiles', $class, true)) && !in_array('masonry', $class, true)) {
    $count = count($posts);
    if ($count === 5 || $count === 6) {
        $class[] = 'tf_tiles_' . $count;
    } else {
        $class[] = 'tf_tiles_more';
    }
}
$class[] = apply_filters('themify_builder_module_loops_wrapper', $fields_args['layout_' . $mod_name], $fields_args, $mod_name); //deprecated backward compatibility
$posts_in_lightbox = isset( $fields_args['lbpost'] ) && $fields_args['lbpost'] === 'yes';
$fields_args['title_tag_' . $mod_name] = themify_whitelist_tag( $fields_args['title_tag_' . $mod_name], 'h2' );
global $themify;
if (isset($themify) && !empty($posts)) {
    // save a copy
    $themify_save = clone $themify;
    // override $themify object
    $themify->hide_image = $fields_args['hide_feat_img_' . $mod_name];
    $themify->unlink_image = $fields_args['unlink_feat_img_' . $mod_name];
    $themify->hide_title = $fields_args['hide_post_title_' . $mod_name];
    $themify->themify_post_title_tag = $fields_args['title_tag_' . $mod_name];
    $themify->width = $fields_args['img_width_' . $mod_name];
    $themify->height = $fields_args['img_height_' . $mod_name];
    $themify->image_size = $fields_args['image_size_' . $mod_name];
    $themify->unlink_title = $fields_args['unlink_post_title_' . $mod_name];
    $themify->display_content = $fields_args['display_' . $mod_name];
    if ($fields_args['display_' . $mod_name] === 'excerpt' && !empty($fields_args['excerpt_length_' . $mod_name])) {
        if ( Themify_Builder::$frontedit_active === true || Themify_Builder_Model::is_front_builder_activate() || $is_ajax_filter ) {
            /* combat WP's post-excerpt block filtering excerpt_length on REST_REQUEST */
            remove_all_filters( 'excerpt_length' );
            add_filter( 'excerpt_length', 'themify_custom_except_length', 999 );
        }
        $themify->excerpt_length = $fields_args['excerpt_length_' . $mod_name];
        add_filter('the_excerpt', 'themify_custom_except', 999);
    }
    $themify->hide_date = $fields_args['hide_post_date_' . $mod_name];
    $themify->hide_meta = $fields_args['hide_post_meta_' . $mod_name];
    if ($fields_args['hide_post_meta_' . $mod_name] !== 'yes') {
        if ($fields_args['hide_author_' . $mod_name] === 'yes') {
            $themify->hide_meta_author = 'yes';
        }
        if ($fields_args['hide_category_' . $mod_name] === 'yes') {
            $themify->hide_meta_category = 'yes';
            $themify->hide_meta_tag = 'yes';
        }
        if ($fields_args['hide_comment_' . $mod_name] === 'yes') {
            $themify->hide_meta_comment = 'yes';
        }
    }
    $themify->post_layout = $fields_args['layout_' . $mod_name];
    if ('auto_tiles' === $themify->post_layout || !empty($fields_args[$mod_name . '_content_layout']) && in_array($fields_args[$mod_name . '_content_layout'], array('polaroid', 'flip'), true)) {
        $themify->media_position = 'above';
    }
    if ('post' === $mod_name) {
        $themify->post_module_hook = $mod_name;
        if ( $tf_masonry_terms_taxonomy !== null ) {
            $themify->post_module_tax = $tf_masonry_terms_taxonomy;
        } elseif ( isset( $query_taxonomy ) ) {
            $themify->post_module_tax = $query_taxonomy;
        }
        if (isset($fields_args[$mod_name . '_content_layout'])) {
            $themify->post_layout_type = $fields_args[$mod_name . '_content_layout'];
        }
    }
    $themify->lightboxed_permalink = $posts_in_lightbox;
}
if ( true === $post_filter_enabled && function_exists( 'themify_masonry_filter' ) ) {
    if (isset($themify)) {
        $themify->post_filter = 'yes';
    }

    $filter_args = array(
        'query_taxonomy' => $filter_taxonomy,
        'query_category' => '0',
        'el_id' => $element_id
    );
    if (isset($fields_args['filter_hashtag']) && $fields_args['filter_hashtag'] === 'yes') {
        $filter_args['hash_tag'] = true;
    }
    if (true === $ajax_filter_enabled) {
        $filter_args['ajax_filter'] = 'yes';
        $filter_args['ajax_filter_id'] = $builder_id;
        $filter_args['ajax_filter_paged'] = $args['paged'];
        $filter_args['ajax_filter_limit'] = $args['posts_per_page'];
        $fields_args['nav_type'] = 'ajax';
        $cat_filter = isset($fields_args['ajax_filter_categories']) ? $fields_args['ajax_filter_categories'] : 'exclude';
        if (('exclude' === $cat_filter || 'include' === $cat_filter) && !empty($fields_args['ajax_filter_' . $cat_filter])) {
            $filter_args['ajax_filter_' . $cat_filter] = sanitize_text_field($fields_args['ajax_filter_' . $cat_filter]);
        }
        if (isset($fields_args['ajax_sort']) && $fields_args['ajax_sort'] === 'yes') {
            $filter_args['ajax_sort'] = 'yes';
            $filter_args['ajax_sort_order'] = $args['order'];
            $filter_args['ajax_sort_order_by'] = $args['orderby'];
        }
        if ( isset( $fields_args['post_filter_orderby'] ) ) {
            $filter_args['tax_orderby'] = $fields_args['post_filter_orderby'];
        }
        if ( isset( $fields_args['post_filter_order'] ) ) {
            $filter_args['tax_order'] = $fields_args['post_filter_order'];
        }
    }
    $filter_args['post_type'] = $the_query->query['post_type'];
    themify_masonry_filter($filter_args);
    unset($filter_args);
    $class[] = 'masonry';
}
$class = apply_filters('themify_loops_wrapper_class', $class, $fields_args['post_type_' . $mod_name], $fields_args['layout_' . $mod_name], 'builder', $fields_args, $mod_name);
$class[] = 'tf_clear tf_clearfix';
$container_props = apply_filters('themify_builder_blog_container_props', array(
    'class' => $class
    ), $fields_args['post_type_' . $mod_name], $fields_args['layout_' . $mod_name], $fields_args, $mod_name);
if ('ajax' === $fields_args['nav_type'] || true === $is_ajax_filter) {
    $container_props['class'][] = 'tb_ajax_pagination';
    $container_props['data-id'] = $element_id;
}
if (Themify_Builder::$frontedit_active === false) {
    $container_props['data-lazy'] = 1;
}
if (!empty($fields_args['masonry_align']) && 'yes' === $fields_args['masonry_align'] &&  in_array('masonry', $container_props['class'], true)) {
    $container_props['data-layout'] = 'fitRows';
}
$container_props['class'] = implode(' ', $container_props['class']);
?>
    <div <?php echo themify_get_element_attributes($container_props); ?>>
    <?php
    $container_props=$class=null;
    if (!empty($posts)) {
        $isLoop = Themify_Builder::$is_loop;

        // if the active theme is using Themify framework use theme template loop (includes/loop.php file)
        if (themify_is_themify_theme() && ($mod_name === 'post' || Themify_Builder_Model::is_loop_template_exist('loop-' . $mod_name . '.php', 'includes'))) {

            // hooks action
            do_action_ref_array('themify_builder_override_loop_themify_vars', array(
                $themify,
                $mod_name,
                $fields_args
            ));
            Themify_Builder::$is_loop = true;
            echo themify_get_shortcode_template($posts, 'includes/loop', $mod_name);
        } else {
            // use builder template
            global $post;
            if ( isset( $post ) ){
                $saved_post = clone $post;
            }
            $param_image = array(
                'w' => $fields_args['img_width_' . $mod_name],
                'h' => $fields_args['img_height_' . $mod_name]
            );
            if ($fields_args['image_size_' . $mod_name] !== '') {
                $param_image['image_size'] = $fields_args['image_size_' . $mod_name];
            }
            $cl = 'post tf_clearfix';
            if ($mod_name !== 'post') {
                $cl .= ' ' . $mod_name . '-post';
            }
            $is_comment_open = themify_builder_get('setting-comments_posts');
            Themify_Builder::$is_loop = true;
            foreach ($posts as $p):
                $post=$p;
                setup_postdata($p);
                ?>

                    <?php themify_post_before(); // hook   ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class($cl); ?>>

                    <?php themify_post_start(); // hook   ?>

                    <?php
                    if ($fields_args['hide_feat_img_' . $mod_name] !== 'yes') {

                        //check if there is a video url in the custom field
                        if ($vurl = themify_builder_get('video_url', false, false)) {
                            global $wp_embed;

                            themify_before_post_image(); // Hook

                            echo $wp_embed->run_shortcode('[embed]' . esc_url($vurl) . '[/embed]');

                            themify_after_post_image(); // Hook
                        } elseif ($post_image = themify_get_image($param_image)) {

                            themify_before_post_image(); // Hook
                            ?>

                                <figure class="post-image">
                                <?php if ($fields_args['unlink_feat_img_' . $mod_name] === 'yes'): ?>
                                    <?php echo $post_image; ?>
                                <?php else: ?>
                                        <a <?php themify_permalink_attr( [ 'is_lightbox' => $posts_in_lightbox ] ); ?>><?php echo $post_image; ?></a>
                                <?php endif; ?>
                                </figure>

                                    <?php
                                    themify_after_post_image(); // Hook
                                }
                            }
                            ?>

                        <div class="post-content">

                        <?php if ($fields_args['hide_post_date_' . $mod_name] !== 'yes'): ?>
                                <time datetime="<?php the_time('o-m-d') ?>" class="post-date" pubdate><?php echo get_the_date(apply_filters('themify_loop_date', '')) ?></time>
                        <?php endif; //post date   ?>

                            <?php if ($fields_args['hide_post_title_' . $mod_name] !== 'yes'): ?>
                                <?php themify_before_post_title(); // Hook  ?>
                                <<?php echo $fields_args['title_tag_' . $mod_name]; ?> class="post-title">
                                <?php if ($fields_args['unlink_post_title_' . $mod_name] === 'yes'): ?>
                                    <?php the_title(); ?>
                                <?php else: ?>
                                    <a <?php themify_permalink_attr( [ 'is_lightbox' => $posts_in_lightbox ] ); ?>><?php the_title(); ?></a>
                                <?php endif; //unlink post title    ?>
                                </<?php echo $fields_args['title_tag_' . $mod_name]; ?>>
                                <?php themify_after_post_title(); // Hook  ?>
                            <?php endif; //post title  ?>

                            <?php if ($fields_args['hide_post_meta_' . $mod_name] !== 'yes'): ?>
                                <p class="post-meta">
                                    <span class="post-author"><?php the_author_posts_link() ?></span>
                                    <span class="post-category">
                                <?php
                                if ($mod_name === 'post') :
                                    echo get_the_category_list(', ', '', $p->ID);
                                else :
                                    $terms = wp_get_post_terms($p->ID, $mod_name . '-category', array('fields' => 'names'));
                                    if (!is_wp_error($terms) && !empty($terms)) {
                                        echo implode(', ', $terms);
                                    }
                                endif;
                                ?>
                                    </span>
                                        <?php the_tags(' <span class="post-tag">', ', ', '</span>'); ?>
                                        <?php if (!$is_comment_open && comments_open()) : ?>
                                        <span class="post-comment"><?php comments_popup_link(__('0 Comments', 'themify'), __('1 Comment', 'themify'), __('% Comments', 'themify')); ?></span>
                                        <?php endif; //post comment    ?>
                                </p>
                                <?php endif; //post meta    ?>

                                <?php
                                if ($fields_args['display_' . $mod_name] !== 'none') {
                                    // fix the issue more link doesn't output
                                    global $more;
                                    $more = 0;
                                    themify_before_post_content();
                                    if ($fields_args['display_' . $mod_name] === 'excerpt') {
                                        the_excerpt();
                                    } else {
                                        $moreText = themify_builder_get('setting-default_more_text');
                                        if (!$moreText) {
                                            $moreText = __('More &rarr;', 'themify');
                                        }
                                        the_content($moreText);
                                    }
                                    themify_after_post_content();
                                }
                                ?>
                            <?php if ($mod_name === 'testimonial'): ?>
                                <p class="testimonial-author">
                                <?php
                                echo themify_builder_testimonial_author_name($p, 'yes');
                                ?>
                                </p>
                            <?php endif; ?>

                        </div>
                        <!-- /.post-content -->
                                <?php themify_post_end(); // hook    ?>

                    </article>
            <?php themify_post_after(); // hook      ?>

                        <?php
                    endforeach;

                    if ( isset( $saved_post )) {
                        $post = $saved_post;
                        setup_postdata( $saved_post );
                        unset($saved_post);
                    }
                } // end $is_theme_template
                Themify_Builder::$is_loop = $isLoop;
                if (isset($themify_save)) {
                    // revert to original $themify state
                    $themify = clone $themify_save;
                    unset($themify_save);
                }
                if ($fields_args['display_' . $mod_name] === 'excerpt' && !empty($fields_args['excerpt_length_' . $mod_name])) {
                    remove_filter('the_excerpt', 'themify_custom_except', 999);
                }
            } else {
                if (isset($fields_args['no_posts'], $fields_args['no_posts_msg'])) {
                    echo '<div class="tb_no_posts">' , $fields_args['no_posts_msg'] , '</div>';
                } elseif (current_user_can('publish_posts') && true !== $is_ajax_filter) {
                    printf(__('No posts found matching the query. <a href="%s" target="_blank">Click here</a> to add posts.', 'themify'), $args['post_type'] !== 'post' ? admin_url('post-new.php?post_type=' . $args['post_type']) : admin_url('post-new.php'));
                }
            }
            ?>
    </div><!-- .builder-posts-wrap -->
        <?php if ('yes' !== $fields_args['hide_page_nav_' . $mod_name]): ?>
            <?php if ('ajax' === $fields_args['nav_type']): ?>
                <?php
                if ($the_query->max_num_pages > $args['paged']) {
                    if (Themify_Builder::$frontedit_active === false) {
                        Themify_Enqueue_Assets::loadinfiniteCss();
                    }
                    $url = is_single() ? add_query_arg(array('tf-page' => ($args['paged'] + 1)), get_permalink(get_queried_object_id())) : next_posts($the_query->max_num_pages, false);
                    echo '<p class="tf_load_more tf_textc tf_clear"><a data-id="', $element_id, '" href="', esc_url( $url ), '" data-page="', esc_attr($args['paged']), '" class="load-more-button">', __('Load More', 'themify'), '</a></p>';
                }
                ?>
        <?php else: ?>
            <?php echo self::get_pagination('', '', $the_query, $offset) ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php
    do_action('themify_builder_after_template_content_render');
    ?>
</div>
<!-- /module post -->
    <?php
    Themify_Builder_Model::hook_content_end($fields_args);
    if ('post' === $mod_name) {
        $themify->post_module_hook = '';
    }
    $fields_args = $the_query = $args=null;
    