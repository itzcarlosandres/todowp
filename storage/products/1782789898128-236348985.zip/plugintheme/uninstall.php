<?php
/**
 * Uninstall Script
 * Cleans up all plugin data when plugin is deleted
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Notify server about plugin uninstallation
$uuid = get_option('pt_client_license_uuid');
if (!empty($uuid)) {
    // Get domain with subdirectory support (inline - plugin may not be loaded)
    $raw_url = get_site_url();
    $raw_url = preg_replace('#^https?://#i', '', $raw_url);
    $raw_url = preg_replace('#^www\.#i', '', $raw_url);
    $raw_url = preg_replace('#:\d+(/|$)#', '$1', $raw_url);
    $domain = strtolower(trim(strtok($raw_url, '/')));
    if (preg_match('#^([^/]+)/([^/]+)#', preg_replace('#:\d+(/|$)#', '$1', preg_replace('#^www\.#i', '', preg_replace('#^https?://#i', '', get_site_url()))), $m)) {
        $subdir = strtolower(trim($m[2]));
        if (preg_match('/^[a-z0-9][a-z0-9_-]*$/', $subdir)) {
            $domain = strtolower(trim($m[1])) . '/' . $subdir;
        }
    }

    wp_remote_post('https://api.plugintheme.net/api/licenses/deactivate', array(
        'body' => json_encode(array(
            'licenseKey' => $uuid,
            'domain' => $domain,
            'reason' => 'plugin_uninstalled'
        )),
        'headers' => array(
            'Content-Type' => 'application/json'
        ),
        'timeout' => 10,
        'blocking' => false // Don't wait for response
    ));
}

// Delete all plugin options
$options_to_delete = array(
    'pt_client_license_uuid',
    'pt_client_activation_token',
    'pt_client_service_type',
    'pt_client_license_key',
    'pt_client_expires_at',
    'pt_client_activated_at',
    'pt_client_services',
    'pt_client_last_check',
);

foreach ($options_to_delete as $option) {
    delete_option($option);
}

// Remove injected license data
delete_option('elementor_pro_license_key');
delete_option('_elementor_pro_license_v2_data');
delete_option('elementor_pro_license_key_error');


delete_option('unlimited_elements_license_key');
delete_option('unlimited_elements_license_key_error');

delete_option('schema_pro_license_key');
delete_option('brainstrom_products');
delete_option('schema_pro_license_key_error');


delete_option('divi_license_key');
delete_option('et_automatic_updates_options');
delete_option('divi_license_key_error');
