=== PluginTheme ===
Contributors: plugintheme
Tags: license, activation, premium plugins
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 2.0.0-test
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Activate your PluginTheme licenses for premium plugins with one click.

== Description ==

PluginTheme is a license management plugin for customers who purchase from plugintheme.net.

= Features =

* **One-Click Activation**: Activate your license with a single button click
* **Domain-Based**: Automatically finds your license based on your domain
* **Secure**: Uses encrypted tokens for secure activation
* **Multi-Service Support**: Supports multiple premium plugins
* **Easy Management**: Simple admin interface

= How It Works =

1. Purchase a license from plugintheme.net
2. Enter your domain during checkout
3. Install this plugin on your site
4. Click "Activate License" button
5. Done!

== Installation ==

1. Download the plugin zip file
2. Go to WordPress Admin > Plugins > Add New
3. Click "Upload Plugin" and select the zip file
4. Click "Install Now" and then "Activate"
5. Go to PluginTheme menu in WordPress admin
6. Click the activation button

== Frequently Asked Questions ==

= Do I need a license UUID? =

No! The plugin can automatically find your license based on your domain.

= How do I deactivate my license? =

Go to PluginTheme menu in WordPress admin and click the "Deactivate License" button.

= Can I use one license on multiple sites? =

Each license is tied to one domain. Contact support to transfer licenses.

== Changelog ==

== Support ==

For support, please visit https://plugintheme.net/support
