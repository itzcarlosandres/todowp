<?php
/**
 * Plugin Name: PluginTheme
 * Plugin URI: https://plugintheme.net
 * Description: Activates and manages PluginTheme licenses for your WordPress site
 * Version: 2.7.26
 * Author: PluginTheme.net
 * Author URI: https://plugintheme.net
 * Text Domain: plugintheme
 * License: GPL v2 or later
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Prevent multiple copies from loading
if (defined('PT_PLUGIN_LOADED')) {
    return;
}
define('PT_PLUGIN_LOADED', true);

if (!defined('PT_CLIENT_VERSION')) { define('PT_CLIENT_VERSION', '2.7.26'); }
if (!defined('PT_CLIENT_PLUGIN_DIR')) { define('PT_CLIENT_PLUGIN_DIR', plugin_dir_path(__FILE__)); }

/**
 * Get normalized site domain with optional subdirectory.
 * Supports subdirectory WordPress installs (e.g. site.com/blog).
 * All domain extraction should use this function.
 */
function pt_get_site_domain() {
    $url = site_url();

    // Remove protocol
    $url = preg_replace('#^https?://#i', '', $url);

    // Remove www
    $url = preg_replace('#^www\.#i', '', $url);

    // Remove port
    $url = preg_replace('#:\d+(/|$)#', '$1', $url);

    // Extract hostname + optional first path segment
    if (preg_match('#^([^/]+)(?:/([^/]+))?#', $url, $matches)) {
        $hostname = strtolower(trim($matches[1]));
        $subdir = isset($matches[2]) ? strtolower(trim($matches[2])) : '';

        // Validate subdirectory: only alphanumeric, hyphens, underscores
        if ($subdir && preg_match('/^[a-z0-9][a-z0-9_-]*$/', $subdir)) {
            return $hostname . '/' . $subdir;
        }

        return $hostname;
    }

    // Fallback: just hostname
    return strtolower(trim(strtok($url, '/')));
}

// Settings link on plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=plugintheme-license') . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});

// ========== EARLY INITIALIZATION ==========
// This code runs when the plugin loads at the earliest priority
// Only runs if license is active


/**
 * Guard: Prevent Elementor ONE from overwriting valid connect data with empty array.
 * Elementor Editor::update_editor_data writes (array)$response["connectData"] unconditionally.
 * When the API fails, connectData is null => (array)null = [] => destroys valid connect data.
 */
add_filter("update_user_metadata", "pt_guard_elementor_connect_data", 10, 5);
function pt_guard_elementor_connect_data($check, $object_id, $meta_key, $meta_value, $prev_value) {
    $prefix = $GLOBALS["wpdb"]->get_blog_prefix();
    if ($meta_key !== $prefix . "elementor_connect_common_data") {
        return $check;
    }
    if (empty($meta_value) || (is_array($meta_value) && count($meta_value) === 0)) {
        $existing = get_user_meta($object_id, $meta_key, true);
        if (!empty($existing) && is_array($existing) && count($existing) > 0) {
            return false;
        }
    }
    return $check;
}

/**
 * Override Elementor library access tier for Pro template access.
 * Library app hardcodes current_access_tier to "free". With active ecp- license,
 * override to "agency" so Pro templates can be inserted in the editor.
 */
add_filter("elementor/editor/localize_settings", "pt_override_library_access", 999);
add_filter("elementor/common/localize_settings", "pt_override_library_access", 999);
function pt_override_library_access($settings) {
    if (!pt_is_license_active() || !pt_has_real_elementor_key()) {
        return $settings;
    }
    if (isset($settings["library_connect"])) {
        $settings["library_connect"]["current_access_level"] = 20;
        $settings["library_connect"]["current_access_tier"] = "agency";
        $settings["library_connect"]["base_access_level"] = 20;
        $settings["library_connect"]["base_access_tier"] = "agency";
        $settings["library_connect"]["plan_type"] = "agency";
    }
    return $settings;
}
/**
 * Add license key to ALL Elementor connect API requests.
 * Elementor Pro only adds license for Kit Library requests,
 * but template library also requires it for Pro template downloads.
 */
add_filter('elementor/connect/additional-connect-info', 'pt_add_license_to_connect', 11, 2);
function pt_add_license_to_connect($connect_info, $app = null) {
    if (!empty($connect_info['license'])) {
        return $connect_info;
    }
    $key = get_option('elementor_pro_license_key', '');
    if (!empty($key) && (strpos($key, 'ecp-') === 0 || strpos($key, 'ep-') === 0)) {
        $connect_info['license'] = $key;
    }
    return $connect_info;
}

/**
 * Redirect Elementor connect library template download to old API.
 * Connect API's get_template_content rejects ecp- keys ("License api error").
 * Old API (GET /api/v1/templates/{id}?license=KEY) works with ecp- keys.
 */
add_filter('pre_http_request', 'pt_redirect_template_download', 5, 3);
function pt_redirect_template_download($preempt, $args, $url) {
    if (strpos($url, 'my.elementor.com/api/connect/v1/library/get_template_content') === false) {
        return $preempt;
    }

    $template_id = $args['body']['id'] ?? '';
    $license = get_option('elementor_pro_license_key', '');

    if (empty($template_id) || empty($license) || (strpos($license, 'ecp-') !== 0 && strpos($license, 'ep-') !== 0)) {
        return $preempt;
    }

    $old_url = 'https://my.elementor.com/api/v1/templates/' . intval($template_id);
    $response = wp_remote_get($old_url, array(
        'timeout' => 25,
        'body' => array(
            'license' => $license,
            'url' => home_url(),
            'api_version' => $args['body']['api_version'] ?? ELEMENTOR_VERSION,
            'site_lang' => $args['body']['site_lang'] ?? get_bloginfo('language'),
        ),
    ));

    return is_wp_error($response) ? $preempt : $response;
}

add_action('plugins_loaded', 'pt_early_elementor_init', 1);
function pt_early_elementor_init() {
    if (!pt_is_license_active()) {
        return;
    }

    // Elementor Pro: set real key, clean legacy data
    pt_inject_real_elementor_key();

    // Self-heal: ensure connect_data exists for Elementor Pro
    pt_ensure_elementor_connect_data();

    // Unlimited Elements Freemius override
    pt_apply_unlimited_elements_bypass();

    // Divi license activation
    pt_apply_divi_license();
}

/**
 * Self-heal: If Elementor Pro has a real key but connect_data is missing,
 * fetch it from API and set. Runs on every admin page load.
 * Rate limited to once per hour to avoid API spam.
 */
function pt_ensure_elementor_connect_data() {
    if (!is_admin()) {
        return;
    }

    // Only if we have a real Elementor key
    if (!pt_has_real_elementor_key()) {
        return;
    }

    // Check if connect_data exists
    $admin_id = get_current_user_id() ?: 1;
    $connect = get_user_option('elementor_connect_common_data', $admin_id);
    if (!empty($connect) && is_array($connect) && count($connect) > 0) {
        return; // Already has connect_data
    }

    // Rate limit: once per hour
    if (get_transient('pt_connect_data_heal')) {
        return;
    }
    set_transient('pt_connect_data_heal', 1, HOUR_IN_SECONDS);

    // Fetch from API
    $domain = function_exists('pt_get_site_domain') ? pt_get_site_domain() : parse_url(home_url(), PHP_URL_HOST);
    $compat_url = str_replace('/api/licenses', '/api/license-compat', PT_CLIENT_API_URL);
    $response = wp_remote_get($compat_url . '/licenses?domain=' . urlencode($domain), array('timeout' => 10));

    if (is_wp_error($response)) {
        return;
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    foreach (($data['licenses'] ?? array()) as $lic) {
        if (strtolower($lic['service_type'] ?? '') !== 'elementor_pro') continue;
        if (!empty($lic['elementor_connect']) && is_array($lic['elementor_connect'])) {
            update_user_option($admin_id, 'elementor_connect_common_data', $lic['elementor_connect']);
            delete_option('_elementor_pro_api_requests_lock');
            PluginTheme_License_Client::log('Self-heal: connect_data injected for user ' . $admin_id);
            delete_transient('pt_connect_data_heal');

            // Also trigger migration if not done
            if (!in_array('elementor-pro', get_option('elementor_one_migrated_plugins', array()), true)) {
                $migrated = get_option('elementor_one_migrated_plugins', array());
                $migrated[] = 'elementor-pro';
                update_option('elementor_one_migrated_plugins', $migrated, false);
            }

            // Write ONE tokens if available
            if (!empty($lic['elementor_one']) && is_array($lic['elementor_one'])) {
                $one_fields = array('access_token','refresh_token','client_id','client_secret','token_id','home_url','owner_user_id','share_usage_data');
                foreach ($one_fields as $field) {
                    if (isset($lic['elementor_one'][$field]) && $lic['elementor_one'][$field] !== '') {
                        update_option('elementor_one_' . $field, $lic['elementor_one'][$field]);
                    }
                }
                update_option('elementor_one_home_url', home_url());
            }
            break;
        }
    }
}

/**
 * Inject real Elementor Pro license key into WP options.
 * Real keys (ecp-/ep- prefix) are stored in pt_client_services by the API bot.
 * If no real key exists, cleans up any legacy data and writes NOTHING.
 */
function pt_inject_real_elementor_key() {
    $services = get_option('pt_client_services', array());
    if (empty($services['elementor_pro'])) {
        return;
    }

    $key = $services['elementor_pro']['license_key'] ?? '';
    if (empty($key)) {
        return;
    }

    $is_real_key = (strpos($key, 'ecp-') === 0 || strpos($key, 'ep-') === 0);

    if ($is_real_key) {
        // Write real key — Elementor validates via its own API
        $current_key = get_option('elementor_pro_license_key');
        if ($current_key !== $key) {
            update_option('elementor_pro_license_key', $key);
            update_option('elementor_pro_license_status', 'valid');
            // Clear stale license cache so Elementor re-validates from API
            delete_option('_elementor_pro_license_v2_data');
            delete_option('_elementor_pro_license_v2_data_fallback');
            delete_transient('_elementor_pro_license_v2_data');
        } else {
            // Same key — check if cached validation has error (stale site_inactive etc)
            $v2_data = get_option('_elementor_pro_license_v2_data');
            if (!empty($v2_data)) {
                $cached = is_string($v2_data['value'] ?? null) ? json_decode($v2_data['value'], true) : null;
                if (is_array($cached) && empty($cached['success'])) {
                    // Stale error in cache — clear so Elementor re-validates
                    delete_option('_elementor_pro_license_v2_data');
                    delete_option('_elementor_pro_license_v2_data_fallback');
                    delete_transient('_elementor_pro_license_v2_data');
                }
            }
        }
        return;
    }

    // NOT a real key — clean ALL legacy/old data, write NOTHING
    // Bot will generate a real key; until then Elementor Pro runs unlicensed
    pt_cleanup_elementor_fake_data();
}

/**
 * Remove legacy Elementor license/connect data written by old plugin versions.
 * ONLY called when NO real key exists (legacy/hex key path).
 * NEVER touches Elementor's own native data (license cache, connect, site_key).
 */
function pt_cleanup_elementor_fake_data() {
    // Remove legacy WP license key (hex keys written by old plugin)
    $wp_key = get_option('elementor_pro_license_key');
    if (!empty($wp_key) && strpos($wp_key, 'ecp-') !== 0 && strpos($wp_key, 'ep-') !== 0) {
        delete_option('elementor_pro_license_key');
    }

    // Remove legacy license status if key was removed
    if (empty(get_option('elementor_pro_license_key'))) {
        delete_option('elementor_pro_license_status');
        // Only clean cache when there's no valid key at all
        delete_option('_elementor_pro_license_v2_data');
        delete_option('_elementor_pro_license_v2_data_fallback');
        delete_option('elementor_pro_license_data');
        delete_transient('_elementor_pro_license_v2_data');
    }

    // Remove legacy connect data (old plugin wrote pt_ prefixed tokens to options table)
    $connect_data = get_option('elementor_connect_common_data');
    if (!empty($connect_data) && isset($connect_data['access_token']) && strpos($connect_data['access_token'] ?? '', 'pt_') === 0) {
        delete_option('elementor_connect_common_data');
    }
    $user_token = get_option('elementor_connect_user_token');
    if (!empty($user_token) && isset($user_token['access_token']) && strpos($user_token['access_token'] ?? '', 'pt_') === 0) {
        delete_option('elementor_connect_user_token');
    }
    // Do NOT delete elementor_connect_site_key — it's created by Elementor/bot and needed for API validation
}

/**
 * Apply Unlimited Elements Freemius override
 * This injects license data into Freemius SDK runtime
 */
function pt_apply_unlimited_elements_bypass() {
    // Check if Unlimited Elements is active
    if (!function_exists('uefe_fs')) {
        return;
    }

    // Check if UE license exists
    $ue_license = get_option('unlimited_elements_license_key');
    if (empty($ue_license)) {
        return;
    }

    try {
        $fs = uefe_fs();
        $plugin_slug = 'unlimited-elements-for-elementor';
        $module_id = 4036;

        // Get module ID and slug via reflection
        $reflection = new ReflectionClass($fs);

        if ($reflection->hasProperty('_module_id')) {
            $prop = $reflection->getProperty('_module_id');
            $prop->setAccessible(true);
            $module_id = $prop->getValue($fs);
        }

        if ($reflection->hasProperty('_slug')) {
            $prop = $reflection->getProperty('_slug');
            $prop->setAccessible(true);
            $plugin_slug = $prop->getValue($fs);
        }

        // Load FS_Plugin_License class
        if (!class_exists('FS_Plugin_License')) {
            $sdk_path = WP_PLUGIN_DIR . '/unlimited-elements-for-elementor-premium/provider/freemius/includes/entities/class-fs-plugin-license.php';
            if (file_exists($sdk_path)) {
                require_once $sdk_path;
            }
        }

        if (!class_exists('FS_Plugin_License')) {
            return;
        }

        // Create and set license
        $license_data = array(
            'id' => 99999999,
            'plugin_id' => $module_id,
            'user_id' => 12345678,
            'plan_id' => 2,
            'pricing_id' => null,
            'quota' => 999,
            'activated' => 1,
            'activated_local' => 1,
            'expiration' => date('Y-m-d H:i:s', strtotime('+1 year')),
            'secret_key' => $ue_license,
            'is_block_features' => false,
            'is_cancelled' => false,
            'is_whitelabeled' => false,
        );

        $license = new FS_Plugin_License((object) $license_data);

        if ($reflection->hasProperty('_license')) {
            $prop = $reflection->getProperty('_license');
            $prop->setAccessible(true);
            $prop->setValue($fs, $license);
        }

        // Also set plan for proper "Professional" display
        if (!class_exists('FS_Plugin_Plan')) {
            $plan_path = WP_PLUGIN_DIR . '/unlimited-elements-for-elementor-premium/provider/freemius/includes/entities/class-fs-plugin-plan.php';
            if (file_exists($plan_path)) {
                require_once $plan_path;
            }
        }

        if (class_exists('FS_Plugin_Plan')) {
            $plan_data = array(
                'id' => 2,
                'plugin_id' => $module_id,
                'name' => 'professional',
                'title' => 'Professional',
                'is_free' => false,
                'license_type' => 0,
                'is_block_features' => false,
            );
            $plan = new FS_Plugin_Plan((object) $plan_data);

            // Inject into _plan
            if ($reflection->hasProperty('_plan')) {
                $prop = $reflection->getProperty('_plan');
                $prop->setAccessible(true);
                $prop->setValue($fs, $plan);
            }

            // Inject into _plans array (needed for get_plan() to work)
            if ($reflection->hasProperty('_plans')) {
                $prop = $reflection->getProperty('_plans');
                $prop->setAccessible(true);
                $prop->setValue($fs, array($plan));
            }
        }

        // Enable white label mode to hide sensitive info
        $fs_accounts = get_option('fs_accounts');
        if (is_array($fs_accounts)) {
            $changed = false;

            if (isset($fs_accounts['plugin_data'][$plugin_slug]) && empty($fs_accounts['plugin_data'][$plugin_slug]['is_whitelabeled'])) {
                $fs_accounts['plugin_data'][$plugin_slug]['is_whitelabeled'] = true;
                $changed = true;
            }
            if (isset($fs_accounts['sites'][$plugin_slug]) && empty($fs_accounts['sites'][$plugin_slug]->is_whitelabeled)) {
                $fs_accounts['sites'][$plugin_slug]->is_whitelabeled = true;
                $changed = true;
            }
            if (isset($fs_accounts['licenses'][$plugin_slug]) && empty($fs_accounts['licenses'][$plugin_slug]->is_whitelabeled)) {
                $fs_accounts['licenses'][$plugin_slug]->is_whitelabeled = true;
                $changed = true;
            }

            if ($changed) {
                update_option('fs_accounts', $fs_accounts);
            }
        }

    } catch (Exception $e) {
        // Silent fail
    }
}

// Also apply on init for later loading plugins
add_action('init', 'pt_apply_unlimited_elements_bypass', 1);

/**
 * Apply Divi license activation
 * Sets up Elegant Themes credentials for Divi Theme/Builder
 */
function pt_apply_divi_license() {
    // Check if Divi credentials exist from our license system
    $divi_creds = get_option('pt_divi_credentials');

    if (empty($divi_creds) || !is_array($divi_creds)) {
        return;
    }

    $username = isset($divi_creds['username']) ? $divi_creds['username'] : '';
    $api_key = isset($divi_creds['api_key']) ? $divi_creds['api_key'] : '';

    if (empty($username) || empty($api_key)) {
        return;
    }

    // Check if Divi or Divi Builder is active
    $divi_active = defined('ET_BUILDER_PLUGIN_ACTIVE') ||
                   defined('ET_BUILDER_VERSION') ||
                   function_exists('et_setup_theme');

    if (!$divi_active) {
        return;
    }

    // Set Elegant Themes credentials
    $et_options = array(
        'username' => $username,
        'api_key' => $api_key,
    );

    // Update both site_option and option (Divi checks both)
    $current_site_option = get_site_option('et_automatic_updates_options', array());
    $current_option = get_option('et_automatic_updates_options', array());

    // Only update if different
    if ($current_site_option !== $et_options) {
        update_site_option('et_automatic_updates_options', $et_options);
    }
    if ($current_option !== $et_options) {
        update_option('et_automatic_updates_options', $et_options);
    }

    // Set account status to active
    $current_status = get_site_option('et_account_status');
    if ($current_status !== 'active') {
        update_site_option('et_account_status', 'active');
        update_option('et_account_status', 'active');
    }

    // Clear API key status (remove invalid flag if exists)
    delete_site_option('et_account_api_key_status');
    delete_option('et_account_api_key_status');
}

// Also apply Divi license on init
add_action('init', 'pt_apply_divi_license', 1);

/**
 * Early Elementor Pro license setup
 */
// [REMOVED] pt_early_elementor_license_setup — replaced by pt_inject_real_elementor_key()
// Hex key temporary data is now handled in pt_inject_real_elementor_key (plugins_loaded pri 1)
// Upgrade check is handled by maybe_check_elementor_upgrade (admin_init, class method)

// JS injection for Elementor editor (only if license active)
add_action('admin_head', 'pt_inject_elementor_connect_js', 1);
add_action('elementor/editor/before_enqueue_scripts', 'pt_inject_elementor_connect_js', 1);
function pt_inject_elementor_connect_js() {
    // No legacy JS override — Elementor handles connect natively with real keys
    return;
}

// Hide Freemius SYNC button and problematic UI elements
add_action('admin_head', 'pt_hide_freemius_sync_elements');
function pt_hide_freemius_sync_elements() {
    $screen = get_current_screen();
    if ($screen && strpos($screen->id, 'unlimitedelements') !== false) {
        echo '<style>
            /* Hide SYNC button */
            .fs-submenu-item.pricing,
            a[href*="unlimitedelements-pricing"],
            .fs-action.fs-sync,
            a.fs-sync,
            .button.fs-sync,
            /* Hide Change Plan button */
            .fs-action.fs-change-plan,
            a[href*="change-plan"],
            /* Hide error notices from Freemius */
            .fs-notice.fs-has-title.error,
            .fs-notice.error,
            /* Hide Deactivate License link */
            .fs-action.fs-deactivate-license
            { display: none !important; }
        </style>';
    }
}

// Helper function to check if license is active
function pt_is_license_active() {
    $license_key = get_option('pt_client_license_key');
    $activated_at = get_option('pt_client_activated_at');
    return !empty($license_key) && !empty($activated_at);
}

/**
 * Check if the stored Elementor Pro key is a real (non-hex) key.
 * Real keys start with 'ecp-' or 'ep-' prefix.
 */
function pt_has_real_elementor_key() {
    $services = get_option('pt_client_services', array());
    $key = isset($services['elementor_pro']['license_key']) ? $services['elementor_pro']['license_key'] : '';
    return (strpos($key, 'ecp-') === 0 || strpos($key, 'ep-') === 0);
}
// ========== END EARLY INITIALIZATION ==========


// ========== HTTP REQUEST HANDLING FOR TEMPLATE LIBRARY ==========
// Integrated from MU-plugin - handles template requests

// [REMOVED] PT_Template_Handler class — template library proxy no longer needed.
// Elementor uses real keys natively for template access.

// ========== END HTTP REQUEST HANDLING ==========

define('PT_CLIENT_PLUGIN_URL', plugin_dir_url(__FILE__));


// Auto-cleanup: Detect and remove duplicate PluginTheme plugin folders
add_action('admin_init', 'pt_cleanup_duplicate_plugins');
function pt_cleanup_duplicate_plugins() {
    if (!current_user_can('activate_plugins')) return;
    
    $plugin_dir = WP_PLUGIN_DIR;
    $current_folder = basename(dirname(__FILE__));
    $duplicate_folders = array('starter-client', 'plugintheme-1', 'plugintheme-2');
    
    // If we're in 'plugintheme' folder, also check for old copies
    if ($current_folder === 'plugintheme') {
        foreach ($duplicate_folders as $folder) {
            $folder_path = $plugin_dir . '/' . $folder;
            if (is_dir($folder_path)) {
                // Deactivate if active
                $plugin_file = $folder . '/plugintheme.php';
                if (is_plugin_active($plugin_file)) {
                    deactivate_plugins($plugin_file);
                }
                // Delete the folder
                pt_recursive_delete($folder_path);
            }
        }
    }
}

function pt_recursive_delete($dir) {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        is_dir($path) ? pt_recursive_delete($path) : unlink($path);
    }
    rmdir($dir);
}

if (!defined('PT_CLIENT_API_URL')) { define('PT_CLIENT_API_URL', 'https://api.plugintheme.net/api/licenses'); }

/**
 * Main Client Plugin Class
 */
class PluginTheme_License_Client {

    /**
     * Plugin instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Load dependencies
     */
    private function load_dependencies() {
        require_once PT_CLIENT_PLUGIN_DIR . 'includes/class-activator.php';
        require_once PT_CLIENT_PLUGIN_DIR . 'includes/class-license-injector.php';

        if (is_admin()) {
            require_once PT_CLIENT_PLUGIN_DIR . 'admin/class-admin-page.php';
            // Initialize admin page early to catch admin_init hook
            new PT_Client_Admin_Page();
        }
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('admin_menu', array($this, 'add_admin_menu'));



        // Handle Elementor Pro license API requests (ecp- keys don't work with traditional API)
        add_filter('pre_http_request', array($this, 'handle_elementor_license_api'), 10, 3);


        // Daily license validation
        add_action('wp_loaded', array($this, 'schedule_license_check'));
        add_action('pt_client_daily_license_check', array($this, 'verify_license_validity'));

        // Admin notice for revoked license
        add_action('admin_notices', array($this, 'show_license_revoked_notice'));

        // Plugin update checker
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_updates'));
        add_filter('plugins_api', array($this, 'plugin_info'), 10, 3);

        // Auto-update filter - allows server to control auto-updates
        add_filter('auto_update_plugin', array($this, 'handle_auto_update'), 10, 2);

        // Schedule auto-update check (runs twice daily)
        if (!wp_next_scheduled('pt_auto_update_check')) {
            wp_schedule_event(time(), 'twicedaily', 'pt_auto_update_check');
        }
        add_action('pt_auto_update_check', array($this, 'run_auto_update_check'));


        // Elementor key upgrade: on plugin update, check for real key from API
        add_action('upgrader_process_complete', array($this, 'on_plugin_updated'), 10, 2);

        // Elementor auto-heal: check if real key became invalid, re-provision if needed
        add_action('admin_init', array($this, 'maybe_check_elementor_upgrade'));

        // Auto-recover revoked licenses (v2.7.6 — verify bug fix)
        add_action('admin_init', array($this, 'maybe_recover_revoked'));
    }



    /**
     * Check for Elementor key upgrade (hex→real) or heal (real but invalid).
     * Called on admin_init.
     */
    public function maybe_check_elementor_upgrade() {
        // Lisans aktif değilse hiçbir şey yapma
        if (!pt_is_license_active()) {
            return;
        }

        $services = get_option('pt_client_services', array());
        $ep_key = $services['elementor_pro']['license_key'] ?? '';

        if (empty($ep_key)) {
            // Key empty but service exists — S-6 bug or bot incomplete.
            // Try auto_activate to fetch real key from API (rate limited: 1/hour)
            if (!isset($services['elementor_pro'])) {
                return;
            }
            if (get_transient('pt_elementor_empty_key_check')) {
                return;
            }
            set_transient('pt_elementor_empty_key_check', time(), HOUR_IN_SECONDS);
            self::log('Elementor key empty in services, attempting auto_activate');
            $activator = new PT_Client_Activator();
            $result = $activator->auto_activate();
            if (!empty($result['success'])) {
                self::log('Auto-activate recovered empty Elementor key');
                delete_transient('pt_elementor_empty_key_check');
            }
            return;
        }

        $is_real_key = (strpos($ep_key, 'ecp-') === 0 || strpos($ep_key, 'ep-') === 0);

        if ($is_real_key) {
            // Real key — check if Elementor considers it valid, heal if not
            $this->maybe_heal_elementor_license();
            return;
        }

        // Old hex key — trigger upgrade check via activator
        $activator = new PT_Client_Activator();
        $activator->check_elementor_key_upgrade();
    }

    /**
     * Auto-heal Elementor license when it became invalid on Elementor's side.
     * Triggers re-provision via bot to get a new key.
     * Rate limited: 5 min when healing, 6 hours when OK. Max 3 attempts then 24h cooldown.
     */
    private function maybe_heal_elementor_license() {
        if (get_transient('pt_elementor_heal_check')) {
            return;
        }

        if (!file_exists(WP_PLUGIN_DIR . '/elementor-pro/elementor-pro.php')) {
            set_transient('pt_elementor_heal_check', time(), 6 * HOUR_IN_SECONDS);
            return;
        }

        // Check key validity via Elementor API
        // Connect data (access_token) is NOT checked — bot writes it to its own WP,
        // not the customer site. Key validity alone is sufficient.
        $elementor_key = get_option('elementor_pro_license_key');
        $key_valid = false;

        if (!empty($elementor_key)) {
            $validate_response = wp_remote_post('https://my.elementor.com/api/v2/license/validate', array(
                'body' => array(
                    'license' => $elementor_key,
                    'url' => home_url(),
                    'api_version' => defined('ELEMENTOR_PRO_VERSION') ? ELEMENTOR_PRO_VERSION : '3.35.1',
                    'item_name' => 'starter',
                ),
                'timeout' => 15,
            ));

            if (!is_wp_error($validate_response)) {
                $validate_data = json_decode(wp_remote_retrieve_body($validate_response), true);
                if (is_array($validate_data) && !empty($validate_data['success'])) {
                    $key_valid = true;
                }
            }
        }

        if ($key_valid) {
            // Key valid — also ensure local cache reflects this
            $v2_data = get_option('_elementor_pro_license_v2_data');
            if (!empty($v2_data)) {
                $cached = is_string($v2_data['value'] ?? null) ? json_decode($v2_data['value'], true) : null;
                if (is_array($cached) && empty($cached['success'])) {
                    // Cache has stale error — clear it
                    delete_option('_elementor_pro_license_v2_data');
                    delete_option('_elementor_pro_license_v2_data_fallback');
                    delete_transient('_elementor_pro_license_v2_data');
                }
            }
            delete_option('pt_elementor_heal_attempts');
            set_transient('pt_elementor_heal_check', time(), 6 * HOUR_IN_SECONDS);
            return;
        }

        self::log('Elementor heal needed: key invalid on Elementor API');

        // Elementor says invalid — check our API for new key or trigger re-provision
        self::log('Elementor license invalid (API validation failed), starting heal...');

        $domain = pt_get_site_domain();
        $api_url = defined('PT_CLIENT_API_URL') ? PT_CLIENT_API_URL : 'https://api.plugintheme.net/api/licenses';
        $compat_url = str_replace('/licenses', '/license-compat', $api_url);

        $response = wp_remote_get($compat_url . '/licenses?domain=' . urlencode($domain), array('timeout' => 15));

        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);

            if (!empty($data['licenses'])) {
                foreach ($data['licenses'] as $lic) {
                    if (strtolower($lic['service_type'] ?? '') !== 'elementor_pro') {
                        continue;
                    }

                    $api_key = $lic['license_key'] ?? '';
                    $status = strtoupper($lic['status'] ?? '');

                    if ($status === 'ACTIVE' && (strpos($api_key, 'ecp-') === 0 || strpos($api_key, 'ep-') === 0)) {
                        $services = get_option('pt_client_services', array());
                        $local_key = $services['elementor_pro']['license_key'] ?? '';

                        if ($api_key !== $local_key) {
                            // New key from bot — write it, clear stale cache
                            $services['elementor_pro']['license_key'] = $api_key;
                            update_option('pt_client_services', $services);
                            update_option('elementor_pro_license_key', $api_key);
                            update_option('elementor_pro_license_status', 'valid');
                            delete_option('_elementor_pro_license_v2_data');
                            delete_option('_elementor_pro_license_v2_data_fallback');
                            delete_transient('_elementor_pro_license_v2_data');

                            // Write connect data if available
                            if (!empty($lic['elementor_connect']) && is_array($lic['elementor_connect'])) {
                                $injector = new PT_Client_License_Injector();
                                $injector->inject_elementor_pro($api_key, array('elementor_connect' => $lic['elementor_connect']));
                            }

                            delete_option('pt_elementor_heal_attempts');
                            self::log('Elementor key healed with new key: ' . substr($api_key, 0, 8) . '...');
                            set_transient('pt_elementor_heal_check', time(), 6 * HOUR_IN_SECONDS);
                            return;
                        }

                        // Same key but Elementor says invalid
                        // First try writing connect data — missing connect data is the #1 cause of site_inactive
                        if (!empty($lic['elementor_connect']) && is_array($lic['elementor_connect'])) {
                            $injector = new PT_Client_License_Injector();
                            $injector->inject_service('elementor_pro', $api_key, array('elementor_connect' => $lic['elementor_connect']));
                            self::log('Elementor heal: wrote connect data, will re-check on next cycle');
                            set_transient('pt_elementor_heal_check', time(), 2 * MINUTE_IN_SECONDS);
                            return;
                        }

                        // No connect data — do not auto-provision, user must click Reactivate
                        self::log('Elementor heal: key invalid, no connect data. User should click Reactivate.');
                        set_transient('pt_elementor_heal_check', time(), 30 * MINUTE_IN_SECONDS);
                        return;
                    }

                    if ($status === 'PENDING' || $status === 'PROCESSING') {
                        self::log('Elementor heal: license is ' . $status . ', bot working...');
                        set_transient('pt_elementor_heal_check', time(), 5 * MINUTE_IN_SECONDS);
                        return;
                    }
                }
            }
        }

        // No matching license from API — do not auto-provision, user must click Reactivate
        self::log('Elementor heal: no matching license from API. User should click Reactivate.');
        set_transient('pt_elementor_heal_check', time(), 30 * MINUTE_IN_SECONDS);
    }

    /**
     * Handle plugin update — check for Elementor real key upgrade
     */
    public function on_plugin_updated($upgrader, $options) {
        if (($options['action'] ?? '') !== 'update' || ($options['type'] ?? '') !== 'plugin') {
            return;
        }

        // Clear stale update notice: remove ourselves from response, add to no_update
        $plugin_slug = plugin_basename(dirname(__FILE__) . '/plugintheme.php');
        $update_transient = get_site_transient('update_plugins');
        if ($update_transient) {
            unset($update_transient->response[$plugin_slug]);
            $update_transient->no_update[$plugin_slug] = (object) array(
                'slug' => 'plugintheme',
                'plugin' => $plugin_slug,
                'new_version' => PT_CLIENT_VERSION,
                'url' => 'https://plugintheme.net',
                'package' => '',
            );
            set_site_transient('update_plugins', $update_transient);
        } else {
            delete_site_transient('update_plugins');
        }

        // Reset heal transient so new version checks immediately
        delete_transient('pt_elementor_heal_check');
        delete_option('pt_elementor_heal_attempts');

        // Clear stale Elementor license cache — fresh validation on new version
        delete_option('_elementor_pro_license_v2_data');
        delete_option('_elementor_pro_license_v2_data_fallback');
        delete_transient('_elementor_pro_license_v2_data');

        // Clean heal- prefix from license key if present
        $key = get_option('pt_client_license_key');
        if ($key && strpos($key, 'heal-') === 0) {
            update_option('pt_client_license_key', substr($key, 5));
        }

        $activator = new PT_Client_Activator();
        $activator->check_elementor_key_upgrade();
        $result = $activator->auto_activate();

        // If auto_activate succeeded and license was revoked, clear revoke flags
        if (!empty($result['success']) && get_option('pt_client_license_revoked')) {
            delete_option('pt_client_license_revoked');
            delete_option('pt_client_revoke_reason');
            delete_option('pt_client_revoked_at');
            self::log('Revoke flags cleared after successful auto-activate on update');
        }
    }

    /**
     * Register AJAX actions for Elementor
     */
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        if (!get_option('pt_client_license_uuid')) {
            add_option('pt_client_license_uuid', '');
        }

        if (!get_option('pt_client_services', false)) {
            add_option('pt_client_services', array());
        }
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('PluginTheme License', 'plugintheme'),
            __('PluginTheme', 'plugintheme'),
            'manage_options',
            'plugintheme-license',
            array($this, 'admin_page'),
            'dashicons-admin-network',
            99
        );
    }

    /**
     * Admin page callback
     */
    public function admin_page() {
        $admin_page = new PT_Client_Admin_Page();
        $admin_page->render();
    }

    /**
     * Check license validity (daily)
     */
    public function check_license_validity() {
        $last_check = get_option('pt_client_last_check', 0);

        // Check once per day
        if (time() - $last_check < DAY_IN_SECONDS) {
            return;
        }

        $uuid = get_option('pt_client_license_uuid');

        if (empty($uuid)) {
            return;
        }

        $activator = new PT_Client_Activator();
        $result = $activator->verify_license($uuid);

        update_option('pt_client_last_check', time());

        if (!$result['valid']) {
            // License is no longer valid
            add_action('admin_notices', function() use ($result) {
                ?>
                <div class="notice notice-error">
                    <p>
                        <strong><?php _e('PluginTheme License:', 'plugintheme'); ?></strong>
                        <?php
                        printf(
                            __('Your license is no longer valid. Error: %s', 'plugintheme'),
                            esc_html($result['error'])
                        );
                        ?>
                    </p>
                </div>
                <?php
            });
        }
    }


    /**
     * Intercept Elementor Pro license API calls for ecp-/ep- keys.
     * These connect-provisioned keys don't work with Elementor's traditional license/validate API.
     * Returns a valid response when our system has an active license for this domain.
     */
    public function handle_elementor_license_api($preempt, $args, $url) {
        // Only intercept Elementor license API calls
        if (strpos($url, 'my.elementor.com/api/v2/license/') === false) {
            return $preempt;
        }

        // Get the license key from request body
        $license_key = '';
        if (!empty($args['body']) && is_array($args['body']) && !empty($args['body']['license'])) {
            $license_key = $args['body']['license'];
        }

        // Only intercept for ecp- (connect-provisioned) keys
        if (empty($license_key) || strpos($license_key, 'ecp-') !== 0) {
            return $preempt;
        }

        // Check if we have an active Elementor license in our services
        $services = get_option('pt_client_services', array());
        $has_active = !empty($services['elementor_pro']['license_key']);

        if (!$has_active) {
            return $preempt; // No active Elementor license, let it pass through
        }

        // Determine which endpoint is being called
        $is_validate = strpos($url, 'license/validate') !== false;
        $is_activate = strpos($url, 'license/activate') !== false;

        if (!$is_validate && !$is_activate) {
            return $preempt; // Not validate or activate, let it pass
        }

        self::log('Intercepting Elementor ' . ($is_validate ? 'validate' : 'activate') . ' for ecp- key');

        // Build a successful license response that Elementor Pro expects
        $response_data = array(
            'success' => true,
            'license' => 'valid',
            'item_name' => 'Elementor Pro',
            'expires' => date('Y-m-d H:i:s', strtotime('+1 year')),
            'payment_id' => '1',
            'license_limit' => '1000',
            'site_count' => '1',
            'activations_left' => '999',
            'features' => array(
                'form-submissions',
                'custom_code',
                'custom-css',
                'global-css',
                'custom-attributes',
                'global-widget',
                'display-conditions',
                'stripe-button',
                'editor_comments',
                'element-manager-permissions',
                'activity-log',
                'cf7db',
                'akismet',
                'dynamic-tags-acf',
                'dynamic-tags-pods',
                'dynamic-tags-toolset',
                'dynamic-tags-wc',
                'woocommerce-menu-cart',
                'product-single',
                'product-archive',
                'settings-woocommerce-pages',
                'settings-woocommerce-notices',
            ),
        );

        return array(
            'response' => array(
                'code' => 200,
                'message' => 'OK',
            ),
            'body' => json_encode($response_data),
            'headers' => array('content-type' => 'application/json'),
            'cookies' => array(),
        );
    }

    /**
     * Schedule daily license check
     */
    public function schedule_license_check() {
        if (!wp_next_scheduled('pt_client_daily_license_check')) {
            wp_schedule_event(time(), 'daily', 'pt_client_daily_license_check');
            self::log('Daily license check scheduled');
        }
    }

    /**
     * Verify license validity (runs daily)
     */
    public function verify_license_validity() {
        $uuid = get_option('pt_client_license_uuid');

        if (empty($uuid)) {
            self::log('No license UUID found, skipping validation');
            return;
        }

        self::log('Running daily license validation for UUID: ' . substr($uuid, 0, 8) . '...');

        // Get domain (handle CLI context)
        $domain = pt_get_site_domain();

        // Call server API to verify
        $response = wp_remote_post(PT_CLIENT_API_URL . '/verify', array(
            'body' => json_encode(array(
                'licenseKey' => $uuid,
                'domain' => $domain,
            )),
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'timeout' => 15
        ));

        if (is_wp_error($response)) {
            self::log('License verification failed: ' . $response->get_error_message(), 'error');
            return;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (!$data || !isset($data['valid'])) {
            self::log('Invalid response from server', 'error');
            return;
        }

        // Update last check timestamp
        update_option('pt_client_last_check', time());

        if ($data['valid'] === false) {
            // License revoked or not found
            self::log('License is no longer valid on server, revoking locally', 'warning');
            $this->revoke_license($data['reason'] ?? 'License not found on server');
        } else {
            self::log('License validation successful');
        }
    }

    /**
     * Revoke license (remove from local site)
     */
    public function revoke_license($reason = 'Unknown') {
        self::log('Revoking license. Reason: ' . $reason, 'warning');

        // 1. Remove Elementor Pro license data
        delete_option('elementor_pro_license_key');
        delete_transient('_elementor_pro_license_v2_data');

        // 2. Remove our license data
        delete_option('pt_client_license_uuid');
        delete_option('pt_client_license_key');
        delete_option('pt_client_activated');
        delete_option('pt_client_services');

        // 3. Mark as revoked (for admin notice)
        update_option('pt_client_license_revoked', true);
        update_option('pt_client_revoke_reason', $reason);
        update_option('pt_client_revoked_at', current_time('mysql'));

        self::log('License revoked successfully');

        do_action('pt_client_license_revoked', $reason);
    }

    /**
     * Auto-recover from revoked state (v2.7.6).
     * The verify bug (pre-caea3ce5) could falsely revoke valid licenses.
     * This tries auto_activate() once per hour when revoked — if successful, clears revoke flags.
     */
    public function maybe_recover_revoked() {
        if (!get_option('pt_client_license_revoked')) {
            return;
        }

        // Rate limit: try once per hour
        if (get_transient('pt_revoke_recovery_cooldown')) {
            return;
        }
        set_transient('pt_revoke_recovery_cooldown', 1, HOUR_IN_SECONDS);

        self::log('Revoked license detected, attempting auto-recovery...');

        // Clean heal- prefix from license key if present
        $key = get_option('pt_client_license_key');
        if ($key && strpos($key, 'heal-') === 0) {
            $clean_key = substr($key, 5);
            update_option('pt_client_license_key', $clean_key);
            self::log('Cleaned heal- prefix from license key');
        }

        // Try auto_activate (domain-based, no UUID needed)
        $activator = new PT_Client_Activator();
        $result = $activator->auto_activate();

        if (!empty($result['success'])) {
            // Recovery successful — clear ALL revoke flags
            delete_option('pt_client_license_revoked');
            delete_option('pt_client_revoke_reason');
            delete_option('pt_client_revoked_at');
            delete_transient('pt_revoke_recovery_cooldown');

            // Mark as activated
            update_option('pt_client_activated', true);

            self::log('License auto-recovered successfully!');
        } else {
            $error = $result['error'] ?? 'unknown';
            self::log('Auto-recovery failed: ' . $error, 'warning');
        }
    }

    /**
     * Show admin notice if license was revoked
     */
    public function show_license_revoked_notice() {
        if (!get_option('pt_client_license_revoked')) {
            return;
        }

        $reason = get_option('pt_client_revoke_reason', 'Unknown');
        $revoked_at = get_option('pt_client_revoked_at');
        ?>
        <div class="notice notice-error is-dismissible">
            <p>
                <strong><?php _e('PluginTheme License Revoked', 'plugintheme'); ?></strong>
            </p>
            <p>
                <?php
                printf(
                    __('Your license was deactivated on %s. Reason: %s', 'plugintheme'),
                    esc_html($revoked_at),
                    esc_html($reason)
                );
                ?>
            </p>
            <p>
                <?php _e('All premium features have been disabled. Please contact support or renew your license.', 'plugintheme'); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Check for plugin updates
     */
    public function check_for_updates($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $plugin_slug = plugin_basename(__FILE__);

        // Check for updates from server
        $response = wp_remote_get(PT_CLIENT_API_URL . '/plugin-info', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));

        if (is_wp_error($response)) {
            return $transient;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (!$data || !isset($data['version'])) {
            return $transient;
        }

        // Compare versions
        if (version_compare(PT_CLIENT_VERSION, $data['version'], '<')) {
            $plugin_data = array(
                'slug' => 'plugintheme',
                'plugin' => $plugin_slug,
                'new_version' => $data['version'],
                'url' => 'https://plugintheme.net',
                'package' => $data['download_url'],
                'tested' => $data['tested'] ?? '6.4',
                'requires_php' => '8.0',
            );

            $transient->response[$plugin_slug] = (object) $plugin_data;
        } else {
            // Same or newer version — clear any stale update notice
            unset($transient->response[$plugin_slug]);
            $transient->no_update[$plugin_slug] = (object) array(
                'slug' => 'plugintheme',
                'plugin' => $plugin_slug,
                'new_version' => PT_CLIENT_VERSION,
                'url' => 'https://plugintheme.net',
                'package' => '',
            );
        }


        // Check for Elementor Pro updates from our server
        $elementor_pro_slug = "elementor-pro/elementor-pro.php";
        
        if (isset($transient->checked[$elementor_pro_slug])) {
            $current_version = $transient->checked[$elementor_pro_slug];
            
            $update_api_url = str_replace("/licenses", "/updates", PT_CLIENT_API_URL);
            $ep_response = wp_remote_get($update_api_url . "/info/elementor-pro", array(
                "timeout" => 10,
                "headers" => array(
                    "Accept" => "application/json"
                )
            ));

            if (!is_wp_error($ep_response)) {
                $ep_data = json_decode(wp_remote_retrieve_body($ep_response), true);

                if ($ep_data && isset($ep_data["version"])) {
                    if (version_compare($current_version, $ep_data["version"], "<")) {
                        $transient->response[$elementor_pro_slug] = (object) array(
                            "slug" => "elementor-pro",
                            "plugin" => $elementor_pro_slug,
                            "new_version" => $ep_data["version"],
                            "url" => $ep_data["url"] ?? "https://elementor.com/pro/",
                            "package" => $ep_data["package"],
                            "tested" => $ep_data["tested"] ?? "6.8",
                            "requires_php" => $ep_data["requires_php"] ?? "7.4",
                            "icons" => $ep_data["icons"] ?? array(),
                        );
                        
                        self::log("Elementor Pro update available: " . $ep_data["version"]);
                    }
                }
            }
        }

        return $transient;
    }

    /**
     * Handle auto-update decision for plugins
     * Server controls which plugins should auto-update
     */
    public function handle_auto_update($update, $item) {
        // Auto-update PluginTheme plugin itself (critical for recovery fixes)
        if (isset($item->slug) && $item->slug === 'plugintheme') {
            return true;
        }

        // Check if this is Elementor Pro
        if (isset($item->slug) && $item->slug === 'elementor-pro') {
            // Check if server says auto-update is enabled
            $auto_update_enabled = $this->get_plugin_auto_update_status('elementor-pro');

            if ($auto_update_enabled) {
                self::log('Elementor Pro auto-update: ENABLED by server');
                return true;
            } else {
                self::log('Elementor Pro auto-update: DISABLED by server');
                return false;
            }
        }

        return $update;
    }

    /**
     * Get auto-update status from server (cached for 1 hour)
     */
    private function get_plugin_auto_update_status($plugin_slug) {
        $cache_key = 'pt_auto_update_' . $plugin_slug;
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            return $cached === 'yes';
        }

        // Fetch from server
        $update_api_url = str_replace('/licenses', '/updates', PT_CLIENT_API_URL);
        $response = wp_remote_get($update_api_url . '/info/' . $plugin_slug, array(
            'timeout' => 10,
            'headers' => array('Accept' => 'application/json')
        ));

        if (is_wp_error($response)) {
            // On error, default to false (no auto-update)
            set_transient($cache_key, 'no', HOUR_IN_SECONDS);
            return false;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        $auto_update = !empty($data['auto_update']);

        // Cache for 1 hour
        set_transient($cache_key, $auto_update ? 'yes' : 'no', HOUR_IN_SECONDS);

        return $auto_update;
    }

    /**
     * Run auto-update check (cron job)
     * This triggers WordPress to check and apply auto-updates
     */
    public function run_auto_update_check() {
        self::log('Running scheduled auto-update check');

        // Clear cache to get fresh auto-update status
        delete_transient('pt_auto_update_elementor-pro');
        delete_transient('update_plugins');

        // Trigger WordPress update check
        wp_update_plugins();

        // Run auto-updates if available
        if (function_exists('wp_maybe_auto_update')) {
            wp_maybe_auto_update();
        }
    }

    /**
     * Plugin info for update screen
     */
    public function plugin_info($res, $action, $args) {
        // Handle Elementor Pro info request
        if ($action === "plugin_information" && $args->slug === "elementor-pro") {
            $update_api_url = str_replace("/licenses", "/updates", PT_CLIENT_API_URL);
            $response = wp_remote_get($update_api_url . "/info/elementor-pro", array(
                "timeout" => 10,
                "headers" => array(
                    "Accept" => "application/json"
                )
            ));

            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);

                if ($data) {
                    return (object) array(
                        "name" => $data["name"] ?? "Elementor Pro",
                        "slug" => "elementor-pro",
                        "version" => $data["version"],
                        "author" => $data["author"] ?? "<a href=\"https://elementor.com/\">Elementor.com</a>",
                        "homepage" => $data["url"] ?? "https://elementor.com/pro/",
                        "requires" => $data["requires"] ?? "6.0",
                        "tested" => $data["tested"] ?? "6.8",
                        "requires_php" => $data["requires_php"] ?? "7.4",
                        "download_link" => $data["package"],
                        "sections" => $data["sections"] ?? array(
                            "description" => "Elementor Pro - Premium Website Builder",
                            "changelog" => "<h4>" . $data["version"] . "</h4><ul><li>Latest version from PluginTheme</li></ul>"
                        ),
                        "banners" => $data["banners"] ?? array(),
                    );
                }
            }
        }

        if ($action !== 'plugin_information') {
            return $res;
        }

        if ($args->slug !== 'plugintheme') {
            return $res;
        }

        $response = wp_remote_get(PT_CLIENT_API_URL . '/plugin-info', array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));

        if (is_wp_error($response)) {
            return $res;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (!$data) {
            return $res;
        }

        $plugin_info = array(
            'name' => 'PluginTheme License Client',
            'slug' => 'plugintheme',
            'version' => $data['version'],
            'author' => '<a href="https://plugintheme.net">PluginTheme.net</a>',
            'homepage' => 'https://plugintheme.net',
            'requires' => '6.0',
            'tested' => $data['tested'] ?? '6.4',
            'requires_php' => '8.0',
            'download_link' => $data['download_url'],
            'sections' => array(
                'description' => $data['description'] ?? 'PluginTheme License Client manages your premium plugin licenses.',
                'changelog' => $data['changelog'] ?? '<h4>' . $data['version'] . '</h4><ul><li>Bug fixes and improvements</li></ul>'
            ),
        );

        return (object) $plugin_info;
    }


    /**
     * Log helper
     */
    public static function log($message, $level = 'info') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf('[PluginTheme Client] [%s] %s', strtoupper($level), $message));
        }
    }
}

// Initialize plugin
function plugintheme_client() {
    return PluginTheme_License_Client::get_instance();
}

plugintheme_client();
