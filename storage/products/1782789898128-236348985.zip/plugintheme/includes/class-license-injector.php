<?php
/**
 * License Injector
 * Injects license data into WordPress database options
 */

if (!defined('ABSPATH')) {
    exit;
}

class PT_Client_License_Injector {

    /**
     * Inject license for a specific service (new method)
     */
    public function inject_service($service_type, $license_key, $data = array()) {
        $has_elementor_one = !empty($data['elementor_one']) && is_array($data['elementor_one']);
        if (empty($service_type) || (empty($license_key) && !$has_elementor_one)) {
            return false;
        }

        PluginTheme_License_Client::log("Injecting license for service: {$service_type}");

        return $this->do_inject($service_type, $license_key, $data);
    }

    /**
     * Inject license data (legacy method for backward compatibility)
     */
    public function inject($license_data) {
        if (empty($license_data)) {
            return false;
        }

        $service_type = $license_data['service_type'] ?? '';
        $license_key = $license_data['license_key'] ?? '';
        $wp_options_data = $license_data['license_data'] ?? array();

        PluginTheme_License_Client::log("Injecting license data for service: {$service_type}");

        $result = $this->do_inject($service_type, $license_key, $wp_options_data);

        // Store service info (legacy behavior)
        if ($result) {
            $services = get_option('pt_client_services', array());
            $services[$service_type] = array(
                'license_key' => $license_key,
                'activated_at' => current_time('mysql'),
            );
            update_option('pt_client_services', $services);
        }

        return $result;
    }

    /**
     * Internal injection logic
     */
    private function do_inject($service_type, $license_key, $wp_options_data) {

        // Service-specific injection
        switch ($service_type) {
            case 'elementor_pro':
                $this->inject_elementor_pro($license_key, $wp_options_data);
                break;

            case 'unlimited_elements':
                $this->inject_unlimited_elements($license_key, $wp_options_data);
                break;

            case 'schema_pro':
                $this->inject_schema_pro($license_key, $wp_options_data);
                break;

            case 'divi':
                $this->inject_divi($license_key, $wp_options_data);
                break;

            default:
                PluginTheme_License_Client::log("Unknown service type: {$service_type}", 'warning');
                return false;
        }

        return true;
    }

    /**
     * Inject Elementor Pro license
     */
    private function inject_elementor_pro($license_key, $data) {
        $effective_key = $license_key;
        if (isset($data['elementor_pro_license_key'])) {
            $effective_key = $data['elementor_pro_license_key'];
        }

        $is_real_key = (strpos($effective_key, 'ecp-') === 0 || strpos($effective_key, 'ep-') === 0);

        // Write Elementor ONE tokens FIRST (independent of license key)
        // wp-one-package stores these as site options (NOT user options)
        if (!empty($data['elementor_one']) && is_array($data['elementor_one'])) {
            $one_data = $data['elementor_one'];
            $one_fields = array(
                'access_token', 'refresh_token', 'client_id', 'client_secret',
                'token_id', 'home_url', 'owner_user_id', 'share_usage_data',
            );
            foreach ($one_fields as $field) {
                if (isset($one_data[$field]) && $one_data[$field] !== '') {
                    update_option('elementor_one_' . $field, $one_data[$field]);
                }
            }
            // Fix home_url to match this site (bot uses test site URL)
            update_option('elementor_one_home_url', home_url());

            // Clean stale license data that conflicts with ONE
            delete_option('_elementor_pro_license_v2_data');
            delete_option('_elementor_pro_license_v2_data_fallback');
            delete_transient('_elementor_pro_license_v2_data');
            delete_option('_elementor_pro_api_requests_lock');

            PluginTheme_License_Client::log('Elementor ONE tokens written (' . count(array_filter($one_data)) . ' fields)');
        }

        // Write connect data if provided (independent of license key)
        if (!empty($data['elementor_connect']) && is_array($data['elementor_connect'])) {
            $connect = $data['elementor_connect'];
            $admin_id = get_current_user_id() ?: 1;
            update_user_option($admin_id, 'elementor_connect_common_data', $connect);
            delete_option('_elementor_pro_api_requests_lock');
            PluginTheme_License_Client::log('Elementor connect data written via user_option for user ' . $admin_id);
        }

        if (!$is_real_key) {
            if (!empty($data['elementor_one'])) {
                // Elementor ONE — trigger migration to get real license key from Elementor API
                PluginTheme_License_Client::log('Elementor Pro: Elementor ONE mode — triggering migration');
                delete_option('elementor_pro_license_key_error');
                $this->trigger_elementor_one_migration();
                return;
            }
            // NOT a real key and no ONE data — do NOT write anything legacy
            PluginTheme_License_Client::log('Elementor Pro: ignoring non-real key, waiting for bot to generate real key');
            return;
        }

        // REAL KEY — write and clean all legacy data
        update_option('elementor_pro_license_key', $effective_key);
        update_option('elementor_pro_license_status', 'valid');

        // Clean legacy cache — Elementor validates via its own API
        delete_option('_elementor_pro_license_v2_data');
        delete_option('_elementor_pro_license_v2_data_fallback');
        delete_option('elementor_pro_license_data');
        delete_transient('_elementor_pro_license_v2_data');

        // Clean old legacy connect data
        delete_option('elementor_connect_common_data');
        delete_option('elementor_connect_user_token');

        delete_option('elementor_pro_license_key_error');

        PluginTheme_License_Client::log('Elementor Pro real key injected: ' . substr($effective_key, 0, 12) . '...');
    }

    /**
     * Trigger Elementor ONE migration — registers elementor-pro as migrated
     * and calls Editor::update_editor_data to get real license key from Elementor API
     */
    private function trigger_elementor_one_migration() {
        // Step 1: Add elementor-pro to migrated plugins list
        $migrated = get_option('elementor_one_migrated_plugins', array());
        if (!is_array($migrated)) {
            $migrated = array();
        }
        if (!in_array('elementor-pro', $migrated, true)) {
            $migrated[] = 'elementor-pro';
            update_option('elementor_one_migrated_plugins', $migrated, false);
            PluginTheme_License_Client::log('Elementor ONE: added elementor-pro to migrated plugins');
        }

        // Step 2: Trigger Editor::update_editor_data to get license key from Elementor API
        // This requires wp-one-package to be loaded (comes with Elementor free plugin)
        if (class_exists('\ElementorOne\Admin\Services\Editor')) {
            try {
                $editor = \ElementorOne\Admin\Services\Editor::instance();
                $editor->update_editor_data('activate', true);
                PluginTheme_License_Client::log('Elementor ONE: Editor data updated — license key obtained from Elementor API');
            } catch (\Throwable $e) {
                PluginTheme_License_Client::log('Elementor ONE: Editor update failed: ' . $e->getMessage(), 'warning');
                // Non-fatal — tokens are still written, user can manually connect
            }
        } else {
            PluginTheme_License_Client::log('Elementor ONE: Editor class not available (Elementor plugin may need update)', 'warning');
        }
    }

    /**
     * Inject Unlimited Elements license
     */
    private function inject_unlimited_elements($license_key, $data) {
        update_option('unlimited_elements_license_key', $license_key);

        // Direct Freemius override (most reliable method)
        $activated = $this->inject_unlimited_elements_freemius_bypass($license_key);

        if (!$activated) {
            // Fallback: Try AJAX activation
            $activated = $this->activate_unlimited_elements_freemius($license_key);
        }

        if (!$activated) {
            PluginTheme_License_Client::log('Unlimited Elements fallback to option storage', 'warning');
        }

        delete_option('unlimited_elements_license_key_error');

        PluginTheme_License_Client::log('Unlimited Elements license injected, activation status: ' . ($activated ? 'success' : 'fallback'));
    }

    /**
     * Set Unlimited Elements license via direct Freemius override
     * Overrides the Freemius online API check for migrated users
     */
    private function inject_unlimited_elements_freemius_bypass($license_key) {
        if (!function_exists('uefe_fs')) {
            return false;
        }

        try {
            $fs = uefe_fs();
            $plugin_slug = 'unlimited-elements-for-elementor';
            $module_id = 4036;

            // Get reflection
            $reflection = new ReflectionClass($fs);

            // Get module ID from SDK
            if ($reflection->hasProperty('_module_id')) {
                $prop = $reflection->getProperty('_module_id');
                $prop->setAccessible(true);
                $module_id = $prop->getValue($fs);
            }

            // Get slug from SDK
            if ($reflection->hasProperty('_slug')) {
                $prop = $reflection->getProperty('_slug');
                $prop->setAccessible(true);
                $plugin_slug = $prop->getValue($fs);
            }

            // Load Freemius entity classes if not loaded (UE 2.x requires FS_User/FS_Site typed objects)
            $sdk_base = WP_PLUGIN_DIR . '/unlimited-elements-for-elementor-premium/provider/freemius/includes/entities/';
            if (!class_exists('FS_Plugin_License') && file_exists($sdk_base . 'class-fs-plugin-license.php')) {
                require_once $sdk_base . 'class-fs-plugin-license.php';
            }
            if (!class_exists('FS_User') && file_exists($sdk_base . 'class-fs-user.php')) {
                require_once $sdk_base . 'class-fs-user.php';
            }
            if (!class_exists('FS_Site') && file_exists($sdk_base . 'class-fs-site.php')) {
                require_once $sdk_base . 'class-fs-site.php';
            }

            if (!class_exists('FS_Plugin_License')) {
                PluginTheme_License_Client::log('FS_Plugin_License class not found', 'warning');
                return false;
            }

            // Create license data
            $license_data = array(
                'id' => 99999999,
                'plugin_id' => $module_id,
                'user_id' => 12345678,
                'plan_id' => 2,
                'pricing_id' => null,
                'quota' => 999,
                'activated' => 1,
                'activated_local' => 1,
                'expiration' => '2099-12-31 23:59:59',
                'secret_key' => $license_key,
                'is_block_features' => false,
                'is_cancelled' => false,
                'is_whitelabeled' => false,
            );

            // Create FS_Plugin_License object and set
            $license = new FS_Plugin_License((object) $license_data);

            if ($reflection->hasProperty('_license')) {
                $prop = $reflection->getProperty('_license');
                $prop->setAccessible(true);
                $prop->setValue($fs, $license);
            }

            // Prepare user data
            $user_data = array(
                'id' => 12345678,
                'email' => 'customer@plugintheme.net',
                'first' => 'PluginTheme',
                'last' => 'Customer',
                'is_verified' => true,
                'public_key' => 'pk_customer_key',
                'secret_key' => $license_key,
            );

            // Prepare site data
            $site_data = array(
                'id' => 87654321,
                'user_id' => 12345678,
                'plugin_id' => $module_id,
                'url' => home_url(),
                'title' => get_bloginfo('name'),
                'version' => '1.5.151',
                'is_active' => true,
                'is_premium' => true,
                'license_id' => 99999999,
                'plan_id' => 2,
                'uid' => md5(home_url() . 'ue_bypass'),
            );

            // Build user object — prefer FS_User (UE 2.x type-hinted), fallback to stdClass (UE 1.x compat)
            if (class_exists('FS_User')) {
                try {
                    $user = new FS_User((object) $user_data);
                } catch (\Throwable $e) {
                    $user = (object) $user_data;
                }
            } else {
                $user = (object) $user_data;
            }

            // Build site object — prefer FS_Site, fallback to stdClass
            if (class_exists('FS_Site')) {
                try {
                    $site = new FS_Site((object) $site_data);
                } catch (\Throwable $e) {
                    $site = (object) $site_data;
                }
            } else {
                $site = (object) $site_data;
            }

            // Set instance _user property (UE 2.x strict FS_User type-hint requires this)
            if ($reflection->hasProperty('_user')) {
                try {
                    $prop = $reflection->getProperty('_user');
                    $prop->setAccessible(true);
                    $prop->setValue($fs, $user);
                } catch (\Throwable $e) {
                    // Ignore — some SDK versions may use different property name
                }
            }

            // Set instance _site property (for parity with _user)
            if ($reflection->hasProperty('_site')) {
                try {
                    $prop = $reflection->getProperty('_site');
                    $prop->setAccessible(true);
                    $prop->setValue($fs, $site);
                } catch (\Throwable $e) {
                    // Ignore
                }
            }

            // Also update fs_accounts for persistence (DB-level)
            $fs_accounts = get_option('fs_accounts');
            if (!is_array($fs_accounts)) {
                $fs_accounts = array();
            }

            // Store in fs_accounts (FS_User/FS_Site preferred, stdClass fallback)
            $fs_accounts['users'][$plugin_slug] = $user;
            $fs_accounts['sites'][$plugin_slug] = $site;

            if (!isset($fs_accounts['licenses'])) {
                $fs_accounts['licenses'] = array();
            }
            $fs_accounts['licenses'][$plugin_slug] = $license;

            update_option('fs_accounts', $fs_accounts);

            PluginTheme_License_Client::log('Unlimited Elements Freemius override applied successfully');
            return true;

        } catch (Exception $e) {
            PluginTheme_License_Client::log('Unlimited Elements Freemius override error: ' . $e->getMessage(), 'error');
            return false;
        }
    }

    /**
     * Activate Unlimited Elements via Freemius AJAX
     */
    private function activate_unlimited_elements_freemius($license_key) {
        // Check if Unlimited Elements is installed
        if (!function_exists('uefe_fs')) {
            PluginTheme_License_Client::log('Unlimited Elements not installed', 'warning');
            return false;
        }

        try {
            // Get Freemius instance and extract module ID
            $fs = uefe_fs();
            $serialized = serialize($fs);

            // Extract module ID from serialized object
            $module_id = null;

            if (preg_match('/fs_cache_(\d+)/', $serialized, $matches)) {
                $module_id = $matches[1];
            }

            if (!$module_id && preg_match('/_module_id"[^"]*"(\d+)"/', $serialized, $matches)) {
                $module_id = $matches[1];
            }

            if (!$module_id) {
                PluginTheme_License_Client::log('Could not extract Freemius module ID', 'warning');
                return false;
            }

            // Make AJAX activation request
            $response = wp_remote_post(admin_url('admin-ajax.php?_fs_blog_admin=true'), array(
                'body' => array(
                    'action' => 'fs_activate_license_' . $module_id,
                    'security' => wp_create_nonce('fs_activate_license_' . $module_id),
                    'license_key' => $license_key,
                    'module_id' => $module_id
                ),
                'cookies' => $_COOKIE,
                'timeout' => 30,
            ));

            if (is_wp_error($response)) {
                PluginTheme_License_Client::log('Unlimited Elements AJAX failed: ' . $response->get_error_message(), 'warning');
                return false;
            }

            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);

            if (!empty($result['success']) && empty($result['error'])) {
                PluginTheme_License_Client::log('Unlimited Elements activated via Freemius');
                return true;
            }

            return false;

        } catch (Exception $e) {
            PluginTheme_License_Client::log('Unlimited Elements activation error: ' . $e->getMessage(), 'error');
            return false;
        }
    }

    /**
     * Inject Schema Pro license
     */
    private function inject_schema_pro($license_key, $data) {
        update_option('schema_pro_license_key', $license_key);

        // Try Brainstorm Force AJAX activation
        $activated = $this->activate_schema_pro_brainstorm($license_key);

        if (!$activated) {
            // Fallback: Direct option injection
            $this->inject_schema_pro_options($license_key);
        }

        delete_option('schema_pro_license_key_error');

        PluginTheme_License_Client::log('Schema Pro license injected, activation status: ' . ($activated ? 'success' : 'fallback'));
    }

    /**
     * Activate Schema Pro via Brainstorm Force form
     */
    private function activate_schema_pro_brainstorm($license_key) {
        $response = wp_remote_post(admin_url('plugins.php?bsf-inline-license-form=wp-schema-pro'), array(
            'body' => array(
                'bsf_graupi_nonce' => wp_create_nonce('bsf_license_activation_deactivation_nonce'),
                'bsf_activate_license' => 'Activate License',
                'bsf_license_manager' => array(
                    'product_id' => 'wp-schema-pro',
                    'privacy_consent' => 'true',
                    'terms_conditions_consent' => 'true',
                    'license_key' => trim($license_key),
                )
            ),
            'cookies' => $_COOKIE,
            'timeout' => 30,
        ));

        if (is_wp_error($response)) {
            PluginTheme_License_Client::log('Schema Pro activation failed: ' . $response->get_error_message(), 'warning');
            return false;
        }

        // Wait briefly for activation to process
        sleep(1);

        // Check if activation was successful
        global $wpdb;
        $option = get_option('brainstrom_products', array());

        if (is_array($option) &&
            isset($option['plugins']['wp-schema-pro']['status']) &&
            $option['plugins']['wp-schema-pro']['status'] === 'registered') {
            PluginTheme_License_Client::log('Schema Pro activated via Brainstorm Force');
            return true;
        }

        return false;
    }

    /**
     * Direct option injection for Schema Pro (fallback)
     */
    private function inject_schema_pro_options($license_key) {
        $brainstorm_products = get_option('brainstrom_products', array());

        if (!is_array($brainstorm_products)) {
            $brainstorm_products = array();
        }

        if (!isset($brainstorm_products['plugins'])) {
            $brainstorm_products['plugins'] = array();
        }

        // Preserve existing product data if it exists (BSF auto-populates fields)
        $existing = isset($brainstorm_products['plugins']['wp-schema-pro'])
            ? $brainstorm_products['plugins']['wp-schema-pro']
            : array();

        // Merge our activation data with existing BSF data
        $brainstorm_products['plugins']['wp-schema-pro'] = array_merge($existing, array(
            'status' => 'registered',
            'purchase_key' => $license_key,
            'id' => 'wp-schema-pro',
            'type' => 'plugin',
            'template' => 'wp-schema-pro/wp-schema-pro.php',
        ));

        update_option('brainstrom_products', $brainstorm_products);

        PluginTheme_License_Client::log('Schema Pro license injected via direct options');
    }

    /**
     * Inject Divi license
     * Sets Elegant Themes credentials for automatic updates
     */
    private function inject_divi($license_key, $data) {
        // Store API key for reference
        update_option('divi_license_key', $license_key);

        // Get username from data or use default
        $username = isset($data['username']) ? $data['username'] : 'cankarfx';
        $api_key = isset($data['api_key']) ? $data['api_key'] : $license_key;

        // Store credentials in our format for pt_apply_divi_license()
        $divi_creds = array(
            'username' => $username,
            'api_key' => $api_key,
        );
        update_option('pt_divi_credentials', $divi_creds);

        // Also set Elegant Themes options directly
        $et_options = array(
            'username' => $username,
            'api_key' => $api_key,
        );

        update_site_option('et_automatic_updates_options', $et_options);
        update_option('et_automatic_updates_options', $et_options);

        // Set account status to active
        update_site_option('et_account_status', 'active');
        update_option('et_account_status', 'active');

        // Clear any invalid API key status
        delete_site_option('et_account_api_key_status');
        delete_option('et_account_api_key_status');

        delete_option('divi_license_key_error');

        PluginTheme_License_Client::log('Divi license injected: username=' . $username . ', api_key=' . substr($api_key, 0, 10) . '...');
    }

    /**
     * Remove all injected license data
     */
    public function remove_all() {
        $services = get_option('pt_client_services', array());

        foreach (array_keys($services) as $service_type) {
            $this->remove($service_type);
        }

        delete_option('pt_client_services');

        PluginTheme_License_Client::log('All license data removed');
    }

    /**
     * Remove license data for specific service
     */
    public function remove($service_type) {
        switch ($service_type) {
            case 'elementor_pro':
                delete_option('elementor_pro_license_key');
                delete_transient('_elementor_pro_license_v2_data');
                // Clean Elementor ONE tokens
                $one_fields = array('access_token', 'refresh_token', 'client_id', 'client_secret', 'token_id', 'home_url', 'owner_user_id', 'share_usage_data');
                foreach ($one_fields as $field) {
                    delete_option('elementor_one_' . $field);
                }
                break;

            case 'unlimited_elements':
                delete_option('unlimited_elements_license_key');
                break;

            case 'schema_pro':
                delete_option('schema_pro_license_key');
                delete_option('brainstrom_products');
                break;

            case 'divi':
                delete_option('divi_license_key');
                delete_option('pt_divi_credentials');
                delete_option('et_automatic_updates_options');
                delete_site_option('et_automatic_updates_options');
                delete_option('et_account_status');
                delete_site_option('et_account_status');
                break;
        }

        PluginTheme_License_Client::log("License data removed for: {$service_type}");
    }

    /**
     * Alias for remove() - for consistency
     */
    public function remove_service($service_type) {
        return $this->remove($service_type);
    }
}
