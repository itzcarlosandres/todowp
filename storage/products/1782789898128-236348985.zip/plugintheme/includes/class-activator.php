<?php
/**
 * License Activator
 * Handles license activation with api.plugintheme.net
 */

if (!defined('ABSPATH')) {
    exit;
}

class PT_Client_Activator {

    /**
     * API URL
     */
    private $api_url;

    /**
     * Constructor
     */
    public function __construct() {
        $this->api_url = PT_CLIENT_API_URL;
    }

    /**
     * Activate license
     */
    public function activate($license_uuid) {
        $domain = $this->get_site_domain();

        PluginTheme_License_Client::log("Activating license: {$license_uuid} for domain: {$domain}");

        $response = wp_remote_post($this->api_url . '/activate', array(
            'body' => json_encode(array(
                'licenseKey' => $license_uuid,
                'domain' => $domain,
            )),
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ));

        if (is_wp_error($response)) {
            PluginTheme_License_Client::log('Activation request failed: ' . $response->get_error_message(), 'error');

            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data)) {
            return array(
                'success' => false,
                'error' => 'Invalid API response'
            );
        }

        if (!isset($data['success']) || !$data['success']) {
            $error = isset($data['message']) ? $data['message'] : 'Unknown error';
            PluginTheme_License_Client::log('Activation failed: ' . $error, 'error');

            return array(
                'success' => false,
                'error' => $error
            );
        }

        // Store license data
        $license_data = $data['data'];

        update_option('pt_client_license_uuid', $license_uuid);
        update_option('pt_client_activation_token', $license_data['activation_token'] ?? '');
        update_option('pt_client_service_type', $license_data['service_type'] ?? '');
        update_option('pt_client_license_key', $license_data['license_key'] ?? '');
        update_option('pt_client_expires_at', $license_data['expires_at'] ?? '');
        update_option('pt_client_activated_at', current_time('mysql'));

        // Inject license data into WordPress options
        $injector = new PT_Client_License_Injector();
        $injector->inject($license_data);

        PluginTheme_License_Client::log('License activated successfully');

        return array(
            'success' => true,
            'data' => $license_data
        );
    }

    /**
     * Verify license
     */
    public function verify_license($license_uuid) {
        $domain = $this->get_site_domain();

        $response = wp_remote_post($this->api_url . '/verify', array(
            'body' => json_encode(array(
                'licenseKey' => $license_uuid,
                'domain' => $domain,
            )),
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 15,
        ));

        if (is_wp_error($response)) {
            return array(
                'valid' => false,
                'error' => $response->get_error_message()
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data)) {
            return array('valid' => false, 'error' => 'Invalid response');
        }

        return $data;
    }

    /**
     * Get site domain
     */
    private function get_site_domain() {
        return pt_get_site_domain();
    }

    /**
     * Auto-activate license by domain (no UUID required)
     */
    public function auto_activate() {
        $domain = $this->get_site_domain();

        PluginTheme_License_Client::log("Auto-activating license for domain: {$domain}");

        // Use compat endpoint for unmasked keys + license_data
        $compat_url = str_replace('/api/licenses', '/api/license-compat', $this->api_url);
        $response = wp_remote_post($compat_url . '/activate-by-domain', array(
            'body' => json_encode(array(
                'domain' => $domain,
                'client_info' => $this->get_client_info(),
            )),
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ));

        if (is_wp_error($response)) {
            PluginTheme_License_Client::log('Auto-activation request failed: ' . $response->get_error_message(), 'error');

            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data)) {
            return array(
                'success' => false,
                'error' => 'Invalid API response'
            );
        }

        if (!isset($data['success']) || !$data['success']) {
            $error = isset($data['message']) ? $data['message'] : 'No license found for this domain';
            PluginTheme_License_Client::log('Auto-activation failed: ' . $error, 'error');

            return array(
                'success' => false,
                'error' => $error
            );
        }

        // Store license data
        $license_data = $data['data'];

        // Store primary license (backward compatibility)
        update_option('pt_client_license_uuid', $license_data['uuid'] ?? '');
        update_option('pt_client_activation_token', $license_data['activation_token'] ?? '');
        update_option('pt_client_service_type', $license_data['service_type'] ?? '');
        update_option('pt_client_license_key', $license_data['license_key'] ?? '');
        update_option('pt_client_expires_at', $license_data['expires_at'] ?? '');
        update_option('pt_client_activated_at', current_time('mysql'));

        // Process all services (new multi-service support)
        $injector = new PT_Client_License_Injector();

        if (!empty($license_data['services']) && is_array($license_data['services'])) {
            PluginTheme_License_Client::log('Processing ' . count($license_data['services']) . ' services');

            $all_services = array();

            foreach ($license_data['services'] as $service_type => $service_data) {
                PluginTheme_License_Client::log("Injecting service: {$service_type}");

                // Store service data
                $all_services[$service_type] = array(
                    'license_key' => $service_data['license_key'],
                    'uuid' => $service_data['uuid'],
                    'expires_at' => $service_data['expires_at'],
                    'activated_at' => current_time('mysql'),
                );

                // Inject license for this service
                $injector->inject_service($service_type, $service_data['license_key'], $service_data);
            }

            // Store all services
            update_option('pt_client_services', $all_services);
        } else {
            // Fallback: single service (backward compatibility)
            $injector->inject($license_data);

            // Store as single service
            $services = array();
            $services[$license_data['service_type']] = array(
                'license_key' => $license_data['license_key'],
                'uuid' => $license_data['uuid'],
                'activated_at' => current_time('mysql'),
            );
            update_option('pt_client_services', $services);
        }

        PluginTheme_License_Client::log('License auto-activated successfully');

        return array(
            'success' => true,
            'data' => $license_data
        );
    }

    /**
     * Activate a specific service license
     */
    public function activate_service($service_type) {
        $domain = $this->get_site_domain();

        PluginTheme_License_Client::log("Activating service: {$service_type} for domain: {$domain}");

        // Use compat endpoint for unmasked keys + license_data (Divi creds, WPML site key etc.)
        $compat_url = str_replace('/api/licenses', '/api/license-compat', $this->api_url);
        $response = wp_remote_get($compat_url . '/licenses?domain=' . urlencode($domain), array(
            'timeout' => 30,
        ));

        if (is_wp_error($response)) {
            PluginTheme_License_Client::log('Failed to fetch licenses: ' . $response->get_error_message(), 'error');
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data) || !isset($data['success']) || !$data['success']) {
            return array(
                'success' => false,
                'error' => 'Failed to fetch licenses'
            );
        }

        $licenses = $data['licenses'] ?? array();

        // Find the license for this service
        $license = null;
        foreach ($licenses as $lic) {
            $st = strtolower($lic['service_type'] ?? '');
            $status = strtolower($lic['status'] ?? '');
            if ($st === $service_type && $status === 'active') {
                $license = $lic;
                break;
            }
        }

        if (!$license) {
            return array(
                'success' => false,
                'error' => 'No active license found for ' . $service_type
            );
        }

        // Inject the license (compat endpoint returns snake_case + unmasked keys)
        $inject_data = $license['license_data'] ?? array();

        // Pass Elementor connect data if available (for template library)
        if (!empty($license['elementor_connect'])) {
            $inject_data['elementor_connect'] = $license['elementor_connect'];
        }

        // Pass Elementor ONE tokens if available (wp-one-package)
        if (!empty($license['elementor_one'])) {
            $inject_data['elementor_one'] = $license['elementor_one'];
        }

        $license_data = array(
            'service_type' => $license['service_type'] ?? '',
            'license_key' => $license['license_key'] ?? '',
            'uuid' => $license['uuid'] ?? '',
            'expires_at' => $license['expires_at'] ?? '',
            'license_data' => $inject_data,
        );

        $injector = new PT_Client_License_Injector();
        $injector->inject($license_data);

        // Store service activation status
        $services = get_option('pt_client_services', array());
        $services[$service_type] = array(
            'license_key' => $license['licenseKey'] ?? $license['license_key'] ?? '',
            'uuid' => $license['licenseId'] ?? $license['uuid'] ?? '',
            'activated_at' => current_time('mysql'),
        );
        update_option('pt_client_services', $services);

        // Also set global license key for API interception (required for handle_elementor_api)
        update_option('pt_client_license_key', $license['licenseKey'] ?? $license['license_key'] ?? '');

        // Elementor Pro: if key is not real yet, trigger upgrade to get real key from bot
        if ($service_type === 'elementor_pro') {
            $ep_key = $license['license_key'] ?? '';
            $is_real = (strpos($ep_key, 'ecp-') === 0 || strpos($ep_key, 'ep-') === 0);
            if (!$is_real) {
                PluginTheme_License_Client::log('Elementor Pro activated with non-real key, triggering upgrade...');
                $this->check_elementor_key_upgrade();
            }
        }

        PluginTheme_License_Client::log("Service {$service_type} activated successfully");

        return array(
            'success' => true,
            'data' => $license_data
        );
    }

    /**
     * Deactivate license
     */
    public function deactivate() {
        // Clear all license data
        delete_option('pt_client_license_uuid');
        delete_option('pt_client_activation_token');
        delete_option('pt_client_service_type');
        delete_option('pt_client_license_key');
        delete_option('pt_client_expires_at');
        delete_option('pt_client_activated_at');

        // Remove injected license data
        $injector = new PT_Client_License_Injector();
        $injector->remove_all();

        PluginTheme_License_Client::log('License deactivated');

        return true;
    }

    /**
     * Deactivate a specific service license
     */
    public function deactivate_service($service_type) {
        PluginTheme_License_Client::log("Deactivating service: {$service_type}");

        // Remove from pt_client_services
        $services = get_option('pt_client_services', array());
        if (isset($services[$service_type])) {
            unset($services[$service_type]);
            update_option('pt_client_services', $services);
        }

        // Remove injected license data for this service
        $injector = new PT_Client_License_Injector();
        $injector->remove_service($service_type);

        PluginTheme_License_Client::log("Service {$service_type} deactivated successfully");

        return array(
            'success' => true,
            'message' => "Service {$service_type} deactivated"
        );
    }

    /**
     * Get license status
     */
    public function get_status() {
        $license_key = get_option('pt_client_license_key');
        $activated_at = get_option('pt_client_activated_at');

        // Only consider active if we have both license key AND activation timestamp
        if (empty($license_key) || empty($activated_at)) {
            return array(
                'active' => false,
                'message' => __('No license activated', 'plugintheme')
            );
        }

        $uuid = get_option('pt_client_license_uuid');
        $service_type = get_option('pt_client_service_type');
        $expires_at = get_option('pt_client_expires_at');

        return array(
            'active' => true,
            'uuid' => $uuid,
            'service_type' => $service_type,
            'license_key' => $this->obfuscate_key($license_key),
            'expires_at' => $expires_at,
            'activated_at' => $activated_at,
        );
    }

    /**
     * Obfuscate license key
     */
    private function obfuscate_key($key) {
        if (empty($key)) {
            return '';
        }

        $length = strlen($key);

        if ($length <= 8) {
            return str_repeat('*', $length);
        }

        return substr($key, 0, 4) . str_repeat('*', $length - 8) . substr($key, -4);
    }

    /**
     * Get client information
     */
    private function get_client_info() {
        global $wp_version;

        $elementor_version = '';
        if (defined('ELEMENTOR_VERSION')) {
            $elementor_version = ELEMENTOR_VERSION;
        }

        $elementor_pro_version = '';
        if (defined('ELEMENTOR_PRO_VERSION')) {
            $elementor_pro_version = ELEMENTOR_PRO_VERSION;
        }

        return array(
            'plugin_version' => PT_CLIENT_VERSION,
            'wp_version' => $wp_version,
            'elementor_version' => $elementor_version,
            'elementor_pro_version' => $elementor_pro_version,
            'php_version' => PHP_VERSION,
            'site_url' => site_url(),
        );
    }

    /**
     * Check if old hex Elementor key can be upgraded to a real key.
     * Queries the API for a real key, or triggers bot generation if none exists.
     * Rate limited: once per 6 hours via transient.
     */
    public function check_elementor_key_upgrade() {
        // Lisans aktif değilse hiçbir şey yapma
        if (!pt_is_license_active()) {
            return;
        }

        $services = get_option('pt_client_services', array());
        $ep_service = $services['elementor_pro'] ?? null;

        if (!$ep_service) {
            return;
        }

        $key = $ep_service['license_key'] ?? '';
        $is_real = (strpos($key, 'ecp-') === 0 || strpos($key, 'ep-') === 0);

        if ($is_real) {
            return; // Already has real key
        }

        PluginTheme_License_Client::log('Elementor key upgrade check: old hex key detected, checking API...');

        $domain = $this->get_site_domain();
        $compat_url = str_replace('/api/licenses', '/api/license-compat', $this->api_url);

        // Rate limit: once per 6 hours
        if (get_transient('pt_elementor_upgrade_check')) {
            return;
        }
        set_transient('pt_elementor_upgrade_check', time(), 6 * HOUR_IN_SECONDS);

        // Step 1: Check if API already has a real key
        $response = wp_remote_get($compat_url . '/licenses?domain=' . urlencode($domain), array('timeout' => 15));

        if (is_wp_error($response)) {
            return;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($data['licenses'])) {
            return;
        }

        $found_elementor = false;
        foreach ($data['licenses'] as $lic) {
            $st = strtolower($lic['service_type'] ?? '');
            $status = strtoupper($lic['status'] ?? '');
            $api_key = $lic['license_key'] ?? '';

            if ($st !== 'elementor_pro') {
                continue;
            }
            $found_elementor = true;

            if ($status === 'ACTIVE' && $api_key && (strpos($api_key, 'ecp-') === 0 || strpos($api_key, 'ep-') === 0)) {
                // Real key available!
                $services['elementor_pro']['license_key'] = $api_key;
                update_option('pt_client_services', $services);

                // Build payload with connect + ONE tokens
                $payload = array();
                if (!empty($lic['elementor_connect'])) {
                    $payload['elementor_connect'] = $lic['elementor_connect'];
                }
                if (!empty($lic['elementor_one'])) {
                    $payload['elementor_one'] = $lic['elementor_one'];
                }

                $injector = new PT_Client_License_Injector();
                $injector->inject_service('elementor_pro', $api_key, $payload);

                delete_option('_elementor_pro_license_v2_data');
                delete_option('_elementor_pro_license_v2_data_fallback');
                delete_transient('_elementor_pro_license_v2_data');

                PluginTheme_License_Client::log('Elementor key upgraded to real key: ' . substr($api_key, 0, 8) . '...');
                delete_transient('pt_elementor_upgrade_check');
                return;
            }

            if ($status === 'PENDING' || $status === 'PROCESSING') {
                PluginTheme_License_Client::log('Elementor key upgrade: license is ' . $status . ', bot is working on it');
                return;
            }
        }

        // Step 2: API has hex key too — trigger bot
        if ($found_elementor) {
            PluginTheme_License_Client::log('Elementor key upgrade: API also has hex key, requesting real key generation...');
            wp_remote_post($compat_url . '/request-elementor-upgrade', array(
                'body' => json_encode(array('domain' => $domain)),
                'headers' => array('Content-Type' => 'application/json'),
                'timeout' => 10,
            ));
        }
    }
}
