<?php
/**
 * Admin Page
 * Renders the license admin interface - shows only purchased licenses
 */

if (!defined('ABSPATH')) {
    exit;
}

class PT_Client_Admin_Page {

    /**
     * Plugin downloads base URL
     */
    const DOWNLOADS_BASE_URL = 'https://api.plugintheme.net/downloads/plugins/';

    /**
     * Debug properties
     */
    private $_debug_api_url = null;
    private $_debug_error = null;
    private $_debug_response_code = null;
    private $_debug_body = null;

    /**
     * Service configuration for display
     */
    private $service_config = array(
        'elementor_pro' => array(
            'name' => 'Elementor Pro',
            'icon' => 'https://api.plugintheme.net/uploads/media/elementor-pro-license.jpg',
            'description' => 'Advanced page builder with pro widgets and features',
            'check_plugin' => 'elementor-pro/elementor-pro.php',
            'download_slug' => 'elementor-pro',
            'requires_plugin' => 'elementor/elementor.php',
            'requires_name' => 'Elementor (Free)',
            'requires_slug' => 'elementor',
            'product_url' => 'https://plugintheme.net/product/elementor-pro-license/',
        ),
        'jet_plugins' => array(
            'name' => 'Jet Plugins (Crocoblock)',
            'icon' => 'https://api.plugintheme.net/uploads/media/jet-plugins-pro-license.jpg',
            'description' => 'JetEngine, JetElements, JetWooBuilder and more',
            'check_plugins' => array(
                'jet-appointments-booking/jet-appointments-booking.php',
                'jet-blocks/jet-blocks.php',
                'jet-blog/jet-blog.php',
                'jet-booking/jet-booking.php',
                'jet-compare-wishlist/jet-compare-wishlist.php',
                'jet-elements/jet-elements.php',
                'jet-engine/jet-engine.php',
                'jet-menu/jet-menu.php',
                'jet-popup/jet-popup.php',
                'jet-product-tables/jet-product-tables.php',
                'jet-reviews/jet-reviews.php',
                'jet-search/jet-search.php',
                'jet-smart-filters/jet-smart-filters.php',
                'jet-style-manager/jet-style-manager.php',
                'jet-tabs/jet-tabs.php',
                'jet-theme-core/jet-theme-core.php',
                'jet-tricks/jet-tricks.php',
                'jet-woo-builder/jet-woo-builder.php',
                'jet-woo-product-gallery/jet-woo-product-gallery.php',
            ),
            'download_slugs' => array(
                'jet-appointments-booking' => 'JetAppointmentsBooking',
                'jet-blocks' => 'JetBlocks',
                'jet-blog' => 'JetBlog',
                'jet-booking' => 'JetBooking',
                'jet-compare-wishlist' => 'JetCompareWishlist',
                'jet-elements' => 'JetElements',
                'jet-engine' => 'JetEngine',
                'jet-menu' => 'JetMenu',
                'jet-popup' => 'JetPopup',
                'jet-product-tables' => 'JetProductTables',
                'jet-reviews' => 'JetReviews',
                'jet-search' => 'JetSearch',
                'jet-smart-filters' => 'JetSmartFilters',
                'jet-style-manager' => 'JetStyleManager',
                'jet-tabs' => 'JetTabs',
                'jet-theme-core' => 'JetThemeCore',
                'jet-tricks' => 'JetTricks',
                'jet-woo-builder' => 'JetWooBuilder',
                'jet-woo-product-gallery' => 'JetWooProductGallery',
            ),
            'manual_activation' => true,
            'product_url' => 'https://plugintheme.net/product/jetplugins-all-inclusive-license/',
        ),
        'wpml' => array(
            'name' => 'WPML',
            'icon' => 'https://api.plugintheme.net/uploads/media/wpml-license.jpg',
            'description' => 'WordPress Multilingual Plugin for translations',
            'manual_activation' => true,
            'check_plugins' => array(
                'sitepress-multilingual-cms/sitepress.php',
                'otgs-installer-plugin/otgs-installer.php',
            ),
            'download_slug' => 'wpml',
            'product_url' => 'https://plugintheme.net/product/wpml-pro-original-license/',
        ),
        'schema_pro' => array(
            'name' => 'Schema Pro',
            'icon' => 'https://api.plugintheme.net/uploads/media/1.jpg',
            'description' => 'Advanced schema markup for better SEO',
            'check_plugin' => 'wp-schema-pro/wp-schema-pro.php',
            'download_slug' => 'schema-pro',
            'product_url' => 'https://plugintheme.net/product/schema-pro-license/',
        ),
        'unlimited_elements' => array(
            'name' => 'Unlimited Elements',
            'icon' => 'https://api.plugintheme.net/uploads/media/unlimited-elements.jpg',
            'description' => 'Premium Elementor widgets collection',
            'check_plugins' => array(
                'unlimited-elements-for-elementor-premium/unlimited-elements-pro.php',
                'unlimited-elements-for-elementor-premium/unlimited-elements-for-elementor.php',
                'unlimited-elements-for-elementor/unlimited-elements.php',
                'unlimited-elements-pro/unlimited-elements.php',
            ),
            'download_slug' => 'unlimited-elements',
            'product_url' => 'https://plugintheme.net/product/unlimited-elements-pro-license/',
        ),
        'divi' => array(
            'name' => 'Divi Theme & Builder',
            'icon' => 'https://api.plugintheme.net/uploads/media/divi-license.jpg',
            'description' => 'Elegant Themes Divi page builder',
            'check_theme' => 'Divi',
            'check_plugins' => array(
                'divi-builder/divi-builder.php',
            ),
            'download_slugs' => array(
                'divi-theme' => array('name' => 'Divi Theme', 'type' => 'theme'),
                'divi-builder' => array('name' => 'Divi Builder', 'type' => 'plugin'),
            ),
            'product_url' => 'https://plugintheme.net/product/divi-theme-page-builder-original-license/',
        ),
    );

    public function __construct() {
        add_action('wp_ajax_pt_activate_license', array($this, 'ajax_activate'));
        add_action('wp_ajax_pt_deactivate_license', array($this, 'ajax_deactivate'));
        add_action('wp_ajax_pt_refresh_licenses', array($this, 'ajax_refresh_licenses'));
        add_action('wp_ajax_pt_reactivate_license', array($this, 'ajax_reactivate'));
        add_action('wp_ajax_pt_poll_reactivate', array($this, 'ajax_poll_reactivate'));
    }

    /**
     * Get domain for this site
     */
    private function get_domain() {
        return pt_get_site_domain();
    }

    /**
     * Fetch licenses from API
     */
    private function fetch_licenses_from_api() {
        $domain = $this->get_domain();
        // Use compat endpoint for unmasked keys + license_data (WPML site key, Divi creds)
        $compat_url = str_replace('/api/licenses', '/api/license-compat', PT_CLIENT_API_URL);
        $api_url = $compat_url . '/licenses?domain=' . urlencode($domain);

        // Debug info storage
        $this->_debug_api_url = $api_url;
        $this->_debug_error = null;
        $this->_debug_response_code = null;
        $this->_debug_body = null;

        $response = wp_remote_get($api_url, array(
            'timeout' => 30,
            'sslverify' => false,
        ));

        if (is_wp_error($response)) {
            $this->_debug_error = $response->get_error_message();
            return array();
        }

        $this->_debug_response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $this->_debug_body = $body;
        $data = json_decode($body, true);

        if (!is_array($data)) {
            $this->_debug_error = 'json_decode failed or not array. json_last_error: ' . json_last_error();
            return array();
        }

        // Compat endpoint returns { success: true, licenses: [...] }
        if (isset($data['success']) && $data['success'] && isset($data['licenses'])) {
            return $data['licenses'];
        }

        // Fallback: raw array (by-domain format)
        if (isset($data[0])) {
            return $data;
        }

        return array();
    }

    /**
     * Get licenses from API (always fresh)
     */
    private function get_licenses() {
        // Always fetch fresh data on page load
        return $this->fetch_licenses_from_api();
    }

    /**
     * Check if a plugin is installed
     */
    private function is_plugin_installed($plugin_file) {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugins = get_plugins();
        return isset($plugins[$plugin_file]);
    }

    /**
     * Check if a plugin is active
     */
    private function is_plugin_active($plugin_file) {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        return is_plugin_active($plugin_file);
    }

    /**
     * Check if a theme is installed
     */
    private function is_theme_installed($theme_name) {
        $themes = wp_get_themes();
        foreach ($themes as $theme) {
            if ($theme->get('Name') === $theme_name || $theme->get_template() === strtolower($theme_name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if a theme is active
     */
    private function is_theme_active($theme_name) {
        $current_theme = wp_get_theme();
        return $current_theme->get('Name') === $theme_name || $current_theme->get_template() === strtolower($theme_name);
    }

    /**
     * Get local activation status for a service
     */
    private function get_local_service_status($service_key) {
        $services = get_option('pt_client_services', array());
        return isset($services[$service_key]) ? $services[$service_key] : null;
    }

    /**
     * AJAX: Activate license
     */
    public function ajax_activate() {
        check_ajax_referer('pt_license_nonce', 'nonce');

        $service_type = sanitize_text_field($_POST['service_type'] ?? '');

        if (empty($service_type)) {
            wp_send_json_error(array('message' => __('Service type required', 'plugintheme')));
        }

        $activator = new PT_Client_Activator();
        $result = $activator->activate_service($service_type);

        if ($result['success']) {
            // Clear license cache
            delete_transient('pt_client_licenses');

            wp_send_json_success(array(
                'message' => sprintf(__('%s license activated successfully!', 'plugintheme'), $this->service_config[$service_type]['name'] ?? $service_type)
            ));
        } else {
            wp_send_json_error(array(
                'message' => $result['error']
            ));
        }
    }

    /**
     * AJAX: Reactivate Elementor Pro — clean re-provision from scratch
     * 1. Delete all Elementor license data + connect data
     * 2. Call API reason=reactivate (deactivate old key + trigger bot)
     * 3. Poll until new key arrives, then set
     */
    public function ajax_reactivate() {
        check_ajax_referer('pt_license_nonce', 'nonce');
        set_time_limit(120);

        $service_type = sanitize_text_field($_POST['service_type'] ?? '');
        if ($service_type !== 'elementor_pro') {
            wp_send_json_error(array('message' => 'Only Elementor Pro supports reactivation'));
        }

        // Step 0: Clear revoke flags and heal- prefix (verify bug recovery)
        delete_option('pt_client_license_revoked');
        delete_option('pt_client_revoke_reason');
        delete_option('pt_client_revoked_at');
        $key = get_option('pt_client_license_key');
        if ($key && strpos($key, 'heal-') === 0) {
            update_option('pt_client_license_key', substr($key, 5));
        }

        // Step 1: Clean ALL existing Elementor data
        $injector = new PT_Client_License_Injector();
        $injector->remove_service('elementor_pro');

        delete_option('elementor_pro_license_key');
        delete_option('elementor_connect_common_data_key');
        delete_option('_elementor_pro_license_v2_data');
        delete_option('_elementor_pro_license_v2_data_fallback');
        delete_transient('_elementor_pro_license_v2_data');
        delete_transient('pt_elementor_upgrade_check');
        delete_transient('pt_elementor_heal_check');
        delete_option('pt_elementor_heal_attempts');

        // Clean connect data from all admin users
        $admins = get_users(array('role' => 'administrator', 'fields' => 'ID'));
        foreach ($admins as $admin_id) {
            delete_user_meta($admin_id, 'elementor_connect_common_data');
        }

        // Remove from stored services
        $services = get_option('pt_client_services', array());
        unset($services['elementor_pro']);
        update_option('pt_client_services', $services);

        // Step 2: Call API to trigger clean re-provision
        $domain = pt_get_site_domain();
        $compat_url = str_replace('/api/licenses', '/api/license-compat', PT_CLIENT_API_URL);

        $response = wp_remote_post($compat_url . '/request-elementor-upgrade', array(
            'body' => json_encode(array('domain' => $domain, 'reason' => 'reactivate')),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 15,
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'API error: ' . $response->get_error_message()));
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (($data['status'] ?? '') !== 'queued') {
            wp_send_json_error(array('message' => $data['message'] ?? 'Reactivate failed'));
        }

        // Return immediately — JS will poll separately
        wp_send_json_success(array('message' => 'Reactivation started, please wait...', 'polling' => true));
    }

    /**
     * AJAX: Poll for reactivated Elementor key (called by JS polling)
     */
    public function ajax_poll_reactivate() {
        check_ajax_referer('pt_license_nonce', 'nonce');

        $domain = pt_get_site_domain();
        $compat_url = str_replace('/api/licenses', '/api/license-compat', PT_CLIENT_API_URL);
        $url = $compat_url . '/licenses?domain=' . urlencode($domain);

        PluginTheme_License_Client::log('Poll reactivate: checking ' . $url);

        $poll = wp_remote_get($url, array('timeout' => 15));
        if (is_wp_error($poll)) {
            PluginTheme_License_Client::log('Poll reactivate: API error - ' . $poll->get_error_message(), 'error');
            wp_send_json_error(array('status' => 'waiting', 'message' => 'API unreachable: ' . $poll->get_error_message()));
        }

        $body = wp_remote_retrieve_body($poll);
        $poll_data = json_decode($body, true);

        if (empty($poll_data['licenses'])) {
            PluginTheme_License_Client::log('Poll reactivate: no licenses in response');
            wp_send_json_error(array('status' => 'waiting', 'message' => 'No licenses found'));
        }

        foreach (($poll_data['licenses'] ?? array()) as $lic) {
            if (strtolower($lic['service_type'] ?? '') !== 'elementor_pro') continue;
            $k = $lic['license_key'] ?? '';
            $status = strtoupper($lic['status'] ?? '');
            PluginTheme_License_Client::log("Poll reactivate: found elementor_pro status=$status key=" . substr($k, 0, 8) . '...');

            $has_elementor_one = !empty($lic['elementor_one']);
            $has_real_key = $k && (strpos($k, 'ecp-') === 0 || strpos($k, 'ep-') === 0);
            if ($status === 'ACTIVE' && ($has_real_key || $has_elementor_one)) {
                // New real key or Elementor ONE data — set
                PluginTheme_License_Client::log('Poll reactivate: injecting' . ($has_real_key ? ' key ' . substr($k, 0, 8) . '...' : ' elementor_one data'));
                try {
                    $injector = new PT_Client_License_Injector();
                    $inject_data = array('elementor_connect' => $lic['elementor_connect'] ?? null);
                    if ($has_elementor_one) {
                        $inject_data['elementor_one'] = $lic['elementor_one'];
                    }
                    $injector->inject_service('elementor_pro', $k, $inject_data);
                    $services = get_option('pt_client_services', array());
                    $services['elementor_pro'] = array('license_key' => $k, 'uuid' => $lic['uuid'] ?? '', 'activated_at' => current_time('mysql'));
                    update_option('pt_client_services', $services);
                    update_option('pt_client_license_key', $k);
                    delete_transient('pt_client_licenses');
                    PluginTheme_License_Client::log('Poll reactivate: SUCCESS');
                    wp_send_json_success(array('status' => 'done', 'message' => 'Elementor Pro reactivated!'));
                } catch (\Exception $e) {
                    PluginTheme_License_Client::log('Poll reactivate: set error - ' . $e->getMessage(), 'error');
                    wp_send_json_error(array('status' => 'error', 'message' => 'Set failed: ' . $e->getMessage()));
                }
            }
        }

        PluginTheme_License_Client::log('Poll reactivate: no ACTIVE ecp/ep key found yet');
        wp_send_json_error(array('status' => 'waiting', 'message' => 'Still processing...'));
    }

    /**
     * AJAX: Deactivate license
     */
    public function ajax_deactivate() {
        check_ajax_referer('pt_license_nonce', 'nonce');

        $service_type = sanitize_text_field($_POST['service_type'] ?? '');

        if (empty($service_type)) {
            wp_send_json_error(array('message' => __('Service type required', 'plugintheme')));
        }

        $activator = new PT_Client_Activator();
        $result = $activator->deactivate_service($service_type);

        if ($result['success']) {
            // Clear license cache
            delete_transient('pt_client_licenses');

            wp_send_json_success(array(
                'message' => sprintf(__('%s license deactivated successfully!', 'plugintheme'), $this->service_config[$service_type]['name'] ?? $service_type)
            ));
        } else {
            wp_send_json_error(array(
                'message' => $result['error'] ?? __('Deactivation failed', 'plugintheme')
            ));
        }
    }

    /**
     * AJAX: Refresh licenses from server
     */
    public function ajax_refresh_licenses() {
        check_ajax_referer('pt_license_nonce', 'nonce');

        // Clear cache and fetch fresh
        delete_transient('pt_client_licenses');
        $licenses = $this->fetch_licenses_from_api();
        set_transient('pt_client_licenses', $licenses, 300);

        wp_send_json_success(array(
            'message' => __('Licenses refreshed successfully!', 'plugintheme'),
            'licenses' => $licenses
        ));
    }

    /**
     * Render admin page
     */
    public function render() {
        $nonce = wp_create_nonce('pt_license_nonce');
        $domain = $this->get_domain();
        $licenses = $this->get_licenses();

        ?>
        <div class="wrap pt-admin-wrap">
            <h1><?php _e('PluginTheme License Manager', 'plugintheme'); ?></h1>

            <p class="pt-subtitle">
                <?php _e('Your purchased plugin licenses for this domain.', 'plugintheme'); ?>
                <strong><?php _e('Domain:', 'plugintheme'); ?></strong> <?php echo esc_html($domain); ?>
            </p>

            <!-- How to Activate Info Box -->
            <div class="pt-info-box">
                <div class="pt-info-icon">
                    <span class="dashicons dashicons-info"></span>
                </div>
                <div class="pt-info-content">
                    <h3><?php _e('How to Activate Your License', 'plugintheme'); ?></h3>
                    <ol>
                        <li>
                            <?php _e('Purchase the license you want from', 'plugintheme'); ?>
                            <a href="https://plugintheme.net/product-category/licenses" target="_blank">plugintheme.net/product-category/licenses</a>
                        </li>
                        <li>
                            <?php _e('Add your domain from', 'plugintheme'); ?>
                            <a href="https://plugintheme.net/account/licenses" target="_blank">plugintheme.net/account/licenses</a>
                        </li>
                        <li><?php _e('Download and install the plugin you want to license', 'plugintheme'); ?></li>
                        <li><?php _e('Click the "Activate" button or manually enter the provided license key', 'plugintheme'); ?></li>
                    </ol>
                </div>
            </div>

            <!-- Status Message -->
            <div id="pt-message" style="display:none;"></div>

            <!-- Refresh Button -->
            <div class="pt-refresh-wrapper">
                <button type="button" id="pt-refresh-btn" class="button pt-refresh-btn">
                    <span class="dashicons dashicons-update"></span> <?php _e('Refresh Licenses', 'plugintheme'); ?>
                </button>
            </div>

            <!-- Services Grid - Show ALL services -->
            <div class="pt-licenses-grid">
                <?php
                // Create a map of purchased licenses by service_type
                $purchased_licenses = array();
                foreach ($licenses as $license) {
                    $st = strtolower($license['serviceType'] ?? $license['service_type'] ?? '');
                    $purchased_licenses[$st] = $license;
                }

                // Loop through ALL services
                foreach ($this->service_config as $service_key => $config):
                    $license = isset($purchased_licenses[$service_key]) ? $purchased_licenses[$service_key] : null;
                    $is_purchased = !empty($license);

                    // Check installation status
                    $is_installed = false;
                    $is_active = false;

                    if (isset($config['check_plugin'])) {
                        $is_installed = $this->is_plugin_installed($config['check_plugin']);
                        $is_active = $this->is_plugin_active($config['check_plugin']);
                    }

                    if (isset($config['check_plugins'])) {
                        // Multiple plugins - any one installed counts
                        foreach ($config['check_plugins'] as $plugin_path) {
                            if ($this->is_plugin_installed($plugin_path)) {
                                $is_installed = true;
                                if ($this->is_plugin_active($plugin_path)) {
                                    $is_active = true;
                                }
                                break;
                            }
                        }
                    }

                    if (isset($config['check_theme'])) {
                        if ($this->is_theme_installed($config['check_theme'])) {
                            $is_installed = true;
                            if ($this->is_theme_active($config['check_theme'])) {
                                $is_active = true;
                            }
                        }
                    }

                    // Check local activation
                    $local_status = $this->get_local_service_status($service_key);
                    $is_locally_activated = !empty($local_status);
                    // Determine card status
                    $card_class = '';
                    $status_badge = '';
                    $status_badge_class = '';
                    $show_activate_btn = false;
                    $show_download_btn = false;
                    $show_buy_btn = false;
                    $license_status = $is_purchased ? strtolower($license['status'] ?? '') : '';

                    if (!$is_purchased) {
                        // Not purchased
                        $card_class = 'pt-license-not-purchased';
                        $status_badge = __('Not Purchased', 'plugintheme');
                        $status_badge_class = 'pt-status-not-purchased';
                        $show_buy_btn = true;
                    } elseif (in_array($license_status, array('pending', 'processing'))) {
                        // License is being provisioned (Puppeteer running)
                        $card_class = 'pt-license-processing';
                        $status_badge = ($license_status === 'processing') ? __('Activating...', 'plugintheme') : __('Pending', 'plugintheme');
                        $status_badge_class = 'pt-status-processing';
                        $has_processing = true;
                    } elseif ($license_status === 'suspended' || $license_status === 'failed') {
                        // License is suspended or failed
                        $card_class = 'pt-license-suspended';
                        $status_badge = $license_status === 'failed' ? __('Failed', 'plugintheme') : __('Suspended', 'plugintheme');
                        $status_badge_class = 'pt-status-suspended';
                    } elseif ($license_status !== 'active') {
                        // Unknown status - treat as suspended
                        $card_class = 'pt-license-suspended';
                        $status_badge = __('Suspended', 'plugintheme');
                        $status_badge_class = 'pt-status-suspended';
                    } elseif (!$is_installed) {
                        $card_class = 'pt-license-not-installed';
                        $status_badge = __('Not Installed', 'plugintheme');
                        $status_badge_class = 'pt-status-not-installed';
                        $show_download_btn = true;
                    } elseif (!empty($config['manual_activation'])) {
                        // Services with their own key system (WPML, Jet Plugins)
                        // User copies the key and activates manually - no Activate button needed
                        $card_class = 'pt-license-active';
                        $status_badge = __('Active', 'plugintheme');
                        $status_badge_class = 'pt-status-active';
                    } elseif ($is_locally_activated) {
                        $card_class = 'pt-license-active';
                        $status_badge = __('Active', 'plugintheme');
                        $status_badge_class = 'pt-status-active';
                    } else {
                        $card_class = 'pt-license-pending';
                        $status_badge = __('Ready to Activate', 'plugintheme');
                        $status_badge_class = 'pt-status-pending';
                        $show_activate_btn = true;
                    }
                ?>
                    <div class="pt-license-card <?php echo $card_class; ?>" data-service="<?php echo esc_attr($service_key); ?>" data-status="<?php echo esc_attr($license_status); ?>">
                        <!-- Card Header: Icon + Title + Badge -->
                        <div class="pt-card-header">
                            <div class="pt-license-icon">
                                <img src="<?php echo esc_url($config['icon']); ?>" alt="<?php echo esc_attr($config['name']); ?>" />
                            </div>
                            <div class="pt-card-title-wrap">
                                <h3 class="pt-license-name"><?php echo esc_html($config['name']); ?></h3>
                                <?php if (!empty($config['description'])): ?>
                                    <p class="pt-license-desc"><?php echo esc_html($config['description']); ?></p>
                                <?php endif; ?>
                            </div>
                            <span class="pt-status-badge <?php echo $status_badge_class; ?>"><?php echo $status_badge; ?></span>
                        </div>

                        <?php if (in_array($license_status, array('pending', 'processing'))): ?>
                        <div class="pt-card-loading-overlay">
                            <span class="pt-spinner pt-spinner-lg"></span>
                            <p><?php echo ($license_status === 'processing') ? __('Activating license...', 'plugintheme') : __('Waiting for activation...', 'plugintheme'); ?></p>
                        </div>
                        <?php endif; ?>

                        <!-- Card Body -->
                        <div class="pt-license-info">
                            <?php if ($is_purchased && $license): ?>
                                <div class="pt-license-meta">
                                    <?php
                                    $exp = $license['expiresAt'] ?? $license['expires_at'] ?? null;
                                    if ($exp): ?>
                                        <span class="pt-license-expires">
                                            📅 <?php printf(__('Expires: %s', 'plugintheme'), date_i18n('M j, Y', strtotime($exp))); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="pt-license-expires pt-license-lifetime">♾️ <?php _e('Lifetime License', 'plugintheme'); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <?php
                            // Show site key for WPML
                            if ($service_key === 'wpml' && $is_purchased && !empty($license['license_data']['wpml_site_key'])):
                                $wpml_site_key = $license['license_data']['wpml_site_key'];
                            ?>
                            <div class="pt-wpml-key-box">
                                <label><?php _e('Your Site Key:', 'plugintheme'); ?></label>
                                <div class="pt-key-copy-wrapper">
                                    <input type="text" readonly value="<?php echo esc_attr($wpml_site_key); ?>" class="pt-site-key-input" id="wpml-site-key" />
                                    <button type="button" class="button pt-copy-btn" data-target="wpml-site-key" title="<?php _e('Copy to clipboard', 'plugintheme'); ?>">
                                        📋
                                    </button>
                                </div>
                                <p class="pt-key-hint"><?php _e('Copy this key and paste it in WPML → Register', 'plugintheme'); ?></p>
                            </div>
                            <?php endif; ?>

                            <?php
                            // Show subkey for Jet Plugins (Crocoblock)
                            if ($service_key === 'jet_plugins' && $is_purchased && !empty($license['license_data']['crocoblock_subkey'])):
                                $crocoblock_subkey = $license['license_data']['crocoblock_subkey'];
                            ?>
                            <div class="pt-wpml-key-box">
                                <label><?php _e('Your License Key:', 'plugintheme'); ?></label>
                                <div class="pt-key-copy-wrapper">
                                    <input type="text" readonly value="<?php echo esc_attr($crocoblock_subkey); ?>" class="pt-site-key-input" id="jet-license-key" />
                                    <button type="button" class="button pt-copy-btn" data-target="jet-license-key" title="<?php _e('Copy to clipboard', 'plugintheme'); ?>">
                                        📋
                                    </button>
                                </div>
                                <p class="pt-key-hint"><?php _e('Copy this key and paste it in Crocoblock → License', 'plugintheme'); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Card Footer -->
                        <?php if ($show_buy_btn): ?>
                        <div class="pt-license-footer">
                            <?php $product_url = isset($config['product_url']) ? $config['product_url'] : 'https://plugintheme.net/product-category/licenses/'; ?>
                            <a href="<?php echo esc_url($product_url); ?>" target="_blank" class="button pt-buy-btn">
                                <?php _e('Buy Now', 'plugintheme'); ?>
                            </a>
                        </div>
                        <?php elseif ($show_activate_btn): ?>
                        <div class="pt-license-footer pt-ready-to-activate-footer">
                            <button type="button" class="button button-primary pt-activate-btn" data-service="<?php echo esc_attr($service_key); ?>">
                                <?php _e('Activate', 'plugintheme'); ?>
                            </button>
                        </div>
                        <?php elseif ($show_download_btn || $is_purchased): ?>
                        <!-- Download buttons for license owners -->
                        <div class="pt-license-footer pt-download-footer">
                            <?php
                            // Check if requires plugin is installed
                            $requires_installed = true;
                            if (isset($config['requires_plugin'])) {
                                $requires_installed = $this->is_plugin_installed($config['requires_plugin']);
                            }
                            ?>

                            <?php if (isset($config['requires_plugin']) && !$requires_installed): ?>
                                <!-- Show requires warning -->
                                <div class="pt-requires-warning">
                                    <p class="pt-requires-text">
                                        ⚠️ <?php printf(__('First install %s, then install %s', 'plugintheme'), '<strong>' . esc_html($config['requires_name']) . '</strong>', '<strong>' . esc_html($config['name']) . '</strong>'); ?>
                                    </p>
                                    <div class="pt-requires-buttons">
                                        <?php
                                        $install_url = isset($config['requires_slug'])
                                            ? self_admin_url('plugin-install.php?s=' . urlencode($config['requires_slug']) . '&tab=search&type=term')
                                            : ($config['requires_url'] ?? '#');
                                        ?>
                                        <a href="<?php echo esc_url($install_url); ?>" class="button pt-requires-btn">
                                            1. <?php printf(__('Install %s', 'plugintheme'), $config['requires_name']); ?>
                                        </a>
                                        <?php if (isset($config['download_slug'])): ?>
                                            <a href="<?php echo esc_url(self::DOWNLOADS_BASE_URL . $config['download_slug'] . '.zip'); ?>" class="button pt-download-btn" target="_blank">
                                                2. ⬇️ <?php printf(__('Download %s', 'plugintheme'), $config['name']); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php elseif (isset($config['download_slugs'])): ?>
                                <!-- Multiple downloads (Jet Plugins, Divi) -->
                                <div class="pt-download-dropdown">
                                    <button type="button" class="button pt-download-toggle">
                                        ⬇️ <?php _e('Download', 'plugintheme'); ?> <span class="dashicons dashicons-arrow-down-alt2"></span>
                                    </button>
                                    <div class="pt-download-menu">
                                        <?php foreach ($config['download_slugs'] as $slug => $item):
                                            $item_name = is_array($item) ? $item['name'] : $item;
                                        ?>
                                            <a href="<?php echo esc_url(self::DOWNLOADS_BASE_URL . $slug . '.zip'); ?>" class="pt-download-item" target="_blank">
                                                <?php echo esc_html($item_name); ?>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php elseif (isset($config['download_slug'])): ?>
                                <!-- Single download -->
                                <a href="<?php echo esc_url(self::DOWNLOADS_BASE_URL . $config['download_slug'] . '.zip'); ?>" class="button pt-download-btn" target="_blank">
                                    ⬇️ <?php _e('Download', 'plugintheme'); ?>
                                </a>
                            <?php endif; ?>
                            <!-- Reactivate button (re-set key if needed) - only for auto-activation services -->
                            <?php if ($is_installed && empty($config['manual_activation'])): ?>
                                <button type="button" class="button pt-activate-btn pt-reactivate-btn" data-service="<?php echo esc_attr($service_key); ?>" title="<?php _e('Re-apply the license key', 'plugintheme'); ?>">
                                    🔄 <?php _e('Reactivate', 'plugintheme'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if (!empty($has_processing)): ?>
            <input type="hidden" id="pt-has-processing" value="1" />
            <?php endif; ?>

            <!-- Status Legend -->
            <div class="pt-status-legend">
                <span class="pt-legend-item"><span class="pt-legend-dot pt-dot-active"></span> <?php _e('Active', 'plugintheme'); ?></span>
                <span class="pt-legend-item"><span class="pt-legend-dot pt-dot-pending"></span> <?php _e('Ready to Activate', 'plugintheme'); ?></span>
                <span class="pt-legend-item"><span class="pt-legend-dot pt-dot-not-installed"></span> <?php _e('Not Installed', 'plugintheme'); ?></span>
                <span class="pt-legend-item"><span class="pt-legend-dot pt-dot-not-purchased"></span> <?php _e('Not Purchased', 'plugintheme'); ?></span>
                <span class="pt-legend-item"><span class="pt-legend-dot pt-dot-suspended"></span> <?php _e('Suspended', 'plugintheme'); ?></span>
            </div>

            <!-- Support -->
            <div class="pt-support-footer">
                <p>
                    <?php _e('Need help?', 'plugintheme'); ?>
                    <a href="https://plugintheme.net/contact" target="_blank"><?php _e('Contact Support', 'plugintheme'); ?></a>
                    &nbsp;|&nbsp;
                    <a href="https://plugintheme.net/account/licenses" target="_blank"><?php _e('Manage Licenses', 'plugintheme'); ?></a>
                </p>
            </div>

        </div>

        <script>
        jQuery(document).ready(function($) {
            var nonce = '<?php echo $nonce; ?>';
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

            // Auto-polling for PENDING/PROCESSING licenses
            if ($('#pt-has-processing').length) {
                var pollCount = 0;
                var maxPolls = 60; // 5 min max (60 * 5s)
                var pollTimer = setInterval(function() {
                    pollCount++;
                    if (pollCount >= maxPolls) {
                        clearInterval(pollTimer);
                        return;
                    }
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: { action: 'pt_refresh_licenses', nonce: nonce },
                        timeout: 15000,
                        success: function(response) {
                            if (response.success && response.data.licenses) {
                                var hasProcessing = false;
                                $.each(response.data.licenses, function(_, lic) {
                                    var st = (lic.status || '').toLowerCase();
                                    if (st === 'pending' || st === 'processing') {
                                        hasProcessing = true;
                                    }
                                });
                                if (!hasProcessing) {
                                    clearInterval(pollTimer);
                                    location.reload();
                                }
                            }
                        }
                    });
                }, 5000);
            }

            // Refresh button
            $('#pt-refresh-btn').on('click', function(e) {
                e.preventDefault();
                var $btn = $(this);
                $btn.prop('disabled', true).html('&#8635; <?php _e('Refreshing...', 'plugintheme'); ?>');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'pt_refresh_licenses',
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        }
                    },
                    complete: function() {
                        $btn.prop('disabled', false).html('&#8635; <?php _e('Refresh', 'plugintheme'); ?>');
                    }
                });
            });

            // Activate button (works for both Activate and Reactivate)
            $(document).on('click', '.pt-activate-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var serviceType = $btn.data('service');
                var isReactivate = $btn.hasClass('pt-reactivate-btn');
                var actionLabel = isReactivate ? '<?php _e('Reactivating', 'plugintheme'); ?>' : '<?php _e('Activating', 'plugintheme'); ?>';
                var $card = $btn.closest('.pt-license-card');

                $btn.prop('disabled', true).html('<span class="pt-spinner"></span> ' + actionLabel + '...');

                // Show loading overlay on the card
                if (!$card.find('.pt-card-loading-overlay').length) {
                    $card.append('<div class="pt-card-loading-overlay"><span class="pt-spinner pt-spinner-lg"></span><p>' + actionLabel + '...</p></div>');
                }

                $('#pt-message')
                    .removeClass('pt-success pt-error')
                    .addClass('pt-warning')
                    .html(actionLabel + ' <?php _e('license, please wait...', 'plugintheme'); ?>')
                    .show();

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: isReactivate ? 'pt_reactivate_license' : 'pt_activate_license',
                        nonce: nonce,
                        service_type: serviceType
                    },
                    timeout: 30000,
                    success: function(response) {
                        if (response.success) {
                            // If polling mode (reactivate), start JS polling
                            if (response.data.polling) {
                                $('#pt-message')
                                    .removeClass('pt-error')
                                    .addClass('pt-warning')
                                    .html('⏳ <?php _e('Activating your license... please wait (up to 60s)', 'plugintheme'); ?>');

                                var pollCount = 0;
                                var maxPolls = 12; // 60s max (12 x 5s)
                                var pollTimer = setInterval(function() {
                                    pollCount++;
                                    if (pollCount >= maxPolls) {
                                        clearInterval(pollTimer);
                                        $('#pt-message')
                                            .removeClass('pt-warning')
                                            .addClass('pt-error')
                                            .html('⏱ <?php _e('Taking longer than expected. Please refresh the page in a minute.', 'plugintheme'); ?>');
                                        $btn.prop('disabled', false).html('🔄 <?php _e('Reactivate', 'plugintheme'); ?>');
                                        $card.find('.pt-card-loading-overlay').remove();
                                        return;
                                    }

                                    $.ajax({
                                        url: ajaxurl,
                                        type: 'POST',
                                        data: { action: 'pt_poll_reactivate', nonce: nonce },
                                        timeout: 15000,
                                        success: function(pollResp) {
                                            if (pollResp.success && pollResp.data.status === 'done') {
                                                clearInterval(pollTimer);
                                                $('#pt-message')
                                                    .removeClass('pt-warning pt-error')
                                                    .addClass('pt-success')
                                                    .html('✓ ' + pollResp.data.message);
                                                setTimeout(function() { location.reload(); }, 1500);
                                            } else {
                                                // Update progress indicator
                                                $('#pt-message').html('⏳ <?php _e('Activating your license...', 'plugintheme'); ?> (' + (pollCount * 5) + 's)');
                                            }
                                        }
                                    });
                                }, 5000);
                            } else {
                                // Normal success (activate)
                                $('#pt-message')
                                    .removeClass('pt-warning pt-error')
                                    .addClass('pt-success')
                                    .html('✓ ' + response.data.message);
                                setTimeout(function() { location.reload(); }, 1500);
                            }
                        } else {
                            $('#pt-message')
                                .removeClass('pt-warning pt-success')
                                .addClass('pt-error')
                                .html('✗ ' + response.data.message);

                            $btn.prop('disabled', false).html(isReactivate ? '🔄 <?php _e('Reactivate', 'plugintheme'); ?>' : '<?php _e('Activate', 'plugintheme'); ?>');
                            $card.find('.pt-card-loading-overlay').remove();
                        }
                    },
                    error: function() {
                        $('#pt-message')
                            .removeClass('pt-warning pt-success')
                            .addClass('pt-error')
                            .html('✗ <?php _e('Connection error. Please try again.', 'plugintheme'); ?>');

                        $btn.prop('disabled', false).html(isReactivate ? '🔄 <?php _e('Reactivate', 'plugintheme'); ?>' : '<?php _e('Activate', 'plugintheme'); ?>');
                        $card.find('.pt-card-loading-overlay').remove();
                    }
                });
            });

            // Deactivate button
            $(document).on('click', '.pt-deactivate-btn', function(e) {
                e.preventDefault();

                if (!confirm('<?php _e('Are you sure you want to deactivate this license?', 'plugintheme'); ?>')) {
                    return;
                }

                var $btn = $(this);
                var serviceType = $btn.data('service');

                $btn.prop('disabled', true).html('<span class="pt-spinner pt-spinner-dark"></span> <?php _e('Deactivating...', 'plugintheme'); ?>');

                $('#pt-message')
                    .removeClass('pt-success pt-error')
                    .addClass('pt-warning')
                    .html('<?php _e('Deactivating license, please wait...', 'plugintheme'); ?>')
                    .show();

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'pt_deactivate_license',
                        nonce: nonce,
                        service_type: serviceType
                    },
                    timeout: 30000,
                    success: function(response) {
                        if (response.success) {
                            $('#pt-message')
                                .removeClass('pt-warning pt-error')
                                .addClass('pt-success')
                                .html('✓ ' + response.data.message);

                            setTimeout(function() {
                                location.reload();
                            }, 1500);
                        } else {
                            $('#pt-message')
                                .removeClass('pt-warning pt-success')
                                .addClass('pt-error')
                                .html('✗ ' + response.data.message);

                            $btn.prop('disabled', false).text('<?php _e('Deactivate', 'plugintheme'); ?>');
                        }
                    },
                    error: function() {
                        $('#pt-message')
                            .removeClass('pt-warning pt-success')
                            .addClass('pt-error')
                            .html('✗ <?php _e('Connection error. Please try again.', 'plugintheme'); ?>');

                        $btn.prop('disabled', false).text('<?php _e('Deactivate', 'plugintheme'); ?>');
                    }
                });
            });

            // Copy button
            $(document).on('click', '.pt-copy-btn', function(e) {
                e.preventDefault();
                var targetId = $(this).data('target');
                var $input = $('#' + targetId);
                $input.select();
                document.execCommand('copy');

                var $btn = $(this);
                var originalText = $btn.html();
                $btn.html('✓');
                setTimeout(function() {
                    $btn.html(originalText);
                }, 1500);
            });

            // Download dropdown toggle
            $(document).on('click', '.pt-download-toggle', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var $dropdown = $(this).closest('.pt-download-dropdown');
                var $menu = $dropdown.find('.pt-download-menu');

                // Close other dropdowns
                $('.pt-download-menu').not($menu).removeClass('pt-show');

                // Toggle this dropdown
                $menu.toggleClass('pt-show');
            });

            // Close dropdown when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('.pt-download-dropdown').length) {
                    $('.pt-download-menu').removeClass('pt-show');
                }
            });
        });
        </script>

        <style>
            .pt-admin-wrap {
                max-width: 1000px;
                margin-top: 20px;
            }
            .pt-subtitle {
                color: #646970;
                font-size: 14px;
                margin-bottom: 25px;
            }
            .pt-subtitle strong {
                margin-left: 15px;
                color: #1d2327;
            }

            /* Info Box - How to Activate */
            .pt-info-box {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 8px;
                padding: 20px 25px;
                margin-bottom: 25px;
                display: flex;
                gap: 20px;
                align-items: flex-start;
                color: #fff;
                box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            }
            .pt-info-icon {
                background: rgba(255,255,255,0.2);
                border-radius: 50%;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .pt-info-icon .dashicons {
                font-size: 20px;
                width: 20px;
                height: 20px;
                color: #fff;
            }
            .pt-info-content h3 {
                margin: 0 0 12px 0;
                font-size: 16px;
                font-weight: 600;
                color: #fff;
            }
            .pt-info-content ol {
                margin: 0;
                padding-left: 20px;
                line-height: 1.8;
            }
            .pt-info-content ol li {
                margin-bottom: 5px;
            }
            .pt-info-content a {
                color: #fff;
                text-decoration: underline;
                font-weight: 500;
            }
            .pt-info-content a:hover {
                opacity: 0.9;
            }

            /* Status Message */
            #pt-message {
                padding: 12px 16px;
                border-radius: 6px;
                margin-bottom: 16px;
                font-size: 14px;
                line-height: 1.5;
            }
            #pt-message.pt-warning {
                background: #fff8e1;
                border: 1px solid #ffcc02;
                color: #7a6100;
            }
            #pt-message.pt-success {
                background: #edf7ed;
                border: 1px solid #4caf50;
                color: #1e4620;
            }
            #pt-message.pt-error {
                background: #fdecea;
                border: 1px solid #ef5350;
                color: #611a15;
            }

            /* Refresh Button Wrapper */
            .pt-refresh-wrapper {
                margin-bottom: 20px;
                text-align: center;
            }
            .pt-refresh-btn {
                background: #00a32a !important;
                border-color: #00a32a !important;
                color: #fff !important;
                padding: 8px 20px !important;
                font-size: 14px !important;
                font-weight: 500 !important;
                border-radius: 4px !important;
                cursor: pointer;
                transition: all 0.2s ease;
            }
            .pt-refresh-btn:hover {
                background: #008a20 !important;
                border-color: #008a20 !important;
                color: #fff !important;
            }
            .pt-refresh-btn .dashicons {
                font-size: 16px;
                width: 16px;
                height: 16px;
                vertical-align: text-bottom;
                margin-right: 4px;
            }
            .pt-refresh-btn:disabled {
                background: #72aee6 !important;
                border-color: #72aee6 !important;
                cursor: not-allowed;
            }

            /* No Licenses State */
            .pt-no-licenses {
                background: #fff;
                border: 1px solid #c3c4c7;
                border-radius: 4px;
                padding: 40px;
                text-align: center;
                margin-bottom: 20px;
            }
            .pt-no-licenses-icon {
                font-size: 48px;
                margin-bottom: 15px;
            }
            .pt-no-licenses h2 {
                margin: 0 0 10px 0;
                color: #1d2327;
            }
            .pt-no-licenses p {
                color: #646970;
                margin: 0 0 10px 0;
            }
            .pt-no-licenses a {
                color: #2271b1;
            }

            /* Licenses Grid - 3 columns */
            .pt-licenses-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
                margin-bottom: 25px;
            }
            @media (max-width: 1200px) {
                .pt-licenses-grid {
                    grid-template-columns: repeat(2, 1fr);
                }
            }
            @media (max-width: 768px) {
                .pt-licenses-grid {
                    grid-template-columns: 1fr;
                }
            }
            .pt-license-card {
                background: #fff;
                border: 1px solid #c3c4c7;
                border-radius: 8px;
                padding: 20px;
                display: flex;
                flex-direction: column;
                gap: 12px;
                transition: all 0.2s ease;
                box-shadow: 0 1px 3px rgba(0,0,0,0.04);
            }
            .pt-license-card:hover {
                border-color: #2271b1;
                box-shadow: 0 3px 8px rgba(0,0,0,0.08);
            }
            .pt-license-active {
                border-left: 4px solid #00a32a;
            }
            .pt-license-pending {
                border-left: 4px solid #dba617;
            }
            .pt-license-not-installed {
                border-left: 4px solid #72777c;
                opacity: 0.8;
            }
            .pt-license-processing {
                border-left: 4px solid #f0ad4e;
                opacity: 0.9;
            }
            .pt-license-suspended {
                border-left: 4px solid #d63638;
                opacity: 0.7;
            }
            .pt-card-header {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .pt-license-icon {
                width: 48px;
                height: 48px;
                flex-shrink: 0;
                border-radius: 8px;
                overflow: hidden;
            }
            .pt-license-icon img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            .pt-card-title-wrap {
                flex: 1;
                min-width: 0;
            }
            .pt-license-name {
                font-size: 16px;
                font-weight: 600;
                color: #1d2327;
                margin: 0 0 2px 0;
            }
            .pt-license-desc {
                font-size: 12px;
                color: #646970;
                margin: 0;
                line-height: 1.4;
            }
            .pt-license-info {
                flex: 1;
            }
            .pt-license-meta {
                font-size: 12px;
                color: #72777c;
                margin-top: 8px;
            }
            .pt-license-lifetime {
                color: #00a32a;
                font-weight: 500;
            }
            .pt-license-footer {
                margin-top: auto;
                padding-top: 12px;
                border-top: 1px solid #f0f0f1;
                text-align: center;
            }
            .pt-ready-to-activate-footer {
                display: flex;
                gap: 8px;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
            }
            .pt-status-badge {
                display: inline-block;
                padding: 4px 10px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
                flex-shrink: 0;
            }
            .pt-status-active {
                background: #d4edda;
                color: #155724;
            }
            .pt-status-pending {
                background: #fff3cd;
                color: #856404;
            }
            .pt-status-not-installed {
                background: #e9ecef;
                color: #6c757d;
            }
            .pt-status-processing {
                background: #fff3cd;
                color: #856404;
                animation: pulse 1.5s ease-in-out infinite;
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.6; }
            }
            .pt-status-suspended {
                background: #f8d7da;
                color: #721c24;
            }
            .pt-status-not-purchased {
                background: #e2e3e5;
                color: #383d41;
            }
            .pt-license-not-purchased {
                border-left: 4px solid #6c757d;
                opacity: 0.85;
            }
            .pt-buy-btn {
                display: block;
                width: 100%;
                text-align: center;
                background: #2271b1 !important;
                border-color: #2271b1 !important;
                color: #fff !important;
                text-decoration: none;
                padding: 8px 16px !important;
            }
            .pt-buy-btn:hover {
                background: #135e96 !important;
                border-color: #135e96 !important;
                color: #fff !important;
            }

            /* WPML Key Box */
            .pt-wpml-key-box {
                margin-top: 12px;
                padding: 10px;
                background: #f0f6fc;
                border: 1px solid #c5d9ed;
                border-radius: 4px;
            }
            .pt-wpml-key-box label {
                display: block;
                font-size: 11px;
                font-weight: 600;
                color: #1d2327;
                margin-bottom: 5px;
            }
            .pt-key-copy-wrapper {
                display: flex;
                gap: 5px;
            }
            .pt-site-key-input {
                flex: 1;
                padding: 6px 10px;
                font-family: monospace;
                font-size: 13px;
                border: 1px solid #8c8f94;
                border-radius: 3px;
                background: #fff;
            }
            .pt-copy-btn {
                padding: 6px 10px !important;
                min-width: 36px;
            }
            .pt-key-hint {
                margin: 6px 0 0 0;
                font-size: 11px;
                color: #646970;
            }

            /* Info Card */
            /* Status Legend */
            .pt-status-legend {
                display: flex;
                flex-wrap: wrap;
                gap: 16px;
                justify-content: center;
                padding: 14px 20px;
                background: #f6f7f7;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                margin-bottom: 20px;
            }
            .pt-legend-item {
                display: flex;
                align-items: center;
                gap: 6px;
                font-size: 13px;
                color: #50575e;
            }
            .pt-legend-dot {
                width: 10px;
                height: 10px;
                border-radius: 50%;
                flex-shrink: 0;
            }
            .pt-dot-active { background: #00a32a; }
            .pt-dot-pending { background: #dba617; }
            .pt-dot-not-installed { background: #72777c; }
            .pt-dot-not-purchased { background: #c3c4c7; }
            .pt-dot-suspended { background: #d63638; }

            /* Support Footer */
            .pt-support-footer {
                text-align: center;
                padding: 12px 0;
                margin-bottom: 10px;
            }
            .pt-support-footer p {
                margin: 0;
                font-size: 13px;
                color: #646970;
            }
            .pt-support-footer a {
                color: #2271b1;
                text-decoration: none;
            }
            .pt-support-footer a:hover {
                text-decoration: underline;
            }

            /* Spinner */
            .pt-spinner {
                display: inline-block;
                width: 12px;
                height: 12px;
                border: 2px solid #fff;
                border-top-color: transparent;
                border-radius: 50%;
                animation: pt-spin 0.8s linear infinite;
                vertical-align: middle;
                margin-right: 6px;
            }
            .pt-spinner-dark {
                border-color: #646970;
                border-top-color: transparent;
            }
            @keyframes pt-spin {
                to { transform: rotate(360deg); }
            }
            .pt-spinner-lg {
                width: 32px !important;
                height: 32px !important;
                border-width: 3px !important;
            }
            .pt-card-loading-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(255, 255, 255, 0.92);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                z-index: 10;
                border-radius: 12px;
                gap: 12px;
            }
            .pt-card-loading-overlay p {
                margin: 0;
                font-size: 14px;
                color: #2271b1;
                font-weight: 500;
            }
            .pt-license-card {
                position: relative;
            }
            .pt-license-processing {
                animation: pt-pulse 2s ease-in-out infinite;
            }
            @keyframes pt-pulse {
                0%, 100% { box-shadow: 0 2px 8px rgba(219, 166, 23, 0.2); }
                50% { box-shadow: 0 2px 16px rgba(219, 166, 23, 0.5); }
            }

            /* Deactivate button */
            .pt-deactivate-btn {
                color: #d63638 !important;
                border-color: #d63638 !important;
            }
            .pt-reactivate-btn {
                background: #f0f0f1 !important;
                color: #2271b1 !important;
                border-color: #2271b1 !important;
                font-size: 12px !important;
                padding: 2px 10px !important;
                margin-top: 8px;
            }
            .pt-reactivate-btn:hover {
                background: #2271b1 !important;
                color: #fff !important;
            }
            .pt-deactivate-btn:hover {
                background: #d63638 !important;
                color: #fff !important;
            }

            /* Download button */
            .pt-download-btn {
                display: inline-block;
                text-decoration: none;
                background: #00a32a !important;
                border-color: #00a32a !important;
                color: #fff !important;
            }
            .pt-download-btn:hover {
                background: #008a20 !important;
                border-color: #008a20 !important;
                color: #fff !important;
            }

            /* Download dropdown */
            .pt-download-dropdown {
                position: relative;
                display: inline-block;
            }
            .pt-download-toggle {
                background: #00a32a !important;
                border-color: #00a32a !important;
                color: #fff !important;
            }
            .pt-download-toggle:hover {
                background: #008a20 !important;
                border-color: #008a20 !important;
            }
            .pt-download-toggle .dashicons {
                font-size: 14px;
                width: 14px;
                height: 14px;
                vertical-align: middle;
                margin-left: 2px;
            }
            .pt-download-menu {
                display: none;
                position: absolute;
                bottom: 100%;
                left: 50%;
                transform: translateX(-50%);
                background: #fff;
                border: 1px solid #c3c4c7;
                border-radius: 4px;
                box-shadow: 0 3px 10px rgba(0,0,0,0.15);
                min-width: 200px;
                max-height: 300px;
                overflow-y: auto;
                z-index: 100;
                margin-bottom: 5px;
            }
            .pt-download-menu.pt-show {
                display: block;
            }
            .pt-download-item {
                display: block;
                padding: 10px 15px;
                color: #1d2327;
                text-decoration: none;
                font-size: 13px;
                border-bottom: 1px solid #f0f0f1;
                transition: background 0.15s;
            }
            .pt-download-item:last-child {
                border-bottom: none;
            }
            .pt-download-item:hover {
                background: #f0f6fc;
                color: #2271b1;
            }
            .pt-download-footer {
                text-align: center;
            }

            /* Install button */
            /* Requires warning */
            .pt-requires-warning {
                text-align: center;
            }
            .pt-requires-text {
                margin: 0 0 12px 0;
                font-size: 13px;
                color: #856404;
                background: #fff3cd;
                padding: 8px 12px;
                border-radius: 4px;
                border: 1px solid #ffc107;
            }
            .pt-requires-buttons {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .pt-requires-btn {
                background: #0073aa !important;
                border-color: #0073aa !important;
                color: #fff !important;
                text-decoration: none;
                text-align: center;
            }
            .pt-requires-btn:hover {
                background: #005a87 !important;
                border-color: #005a87 !important;
                color: #fff !important;
            }

            /* Responsive */
            @media (max-width: 782px) {
                .pt-licenses-grid {
                    grid-template-columns: 1fr;
                }
                .pt-license-card {
                    flex-wrap: wrap;
                }
                .pt-license-status {
                    width: 100%;
                    flex-direction: row;
                    justify-content: space-between;
                    margin-top: 10px;
                    padding-top: 10px;
                    border-top: 1px solid #eee;
                }
            }
        </style>
        <?php
    }
}
